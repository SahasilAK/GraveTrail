-- 03: Two output tables in ONE script. Enrichment + aggregation.
DROP TABLE IF EXISTS extract.account_base;
CREATE TABLE extract.account_base AS
WITH typed AS (
  SELECT a.account_id, a.customer_id, a.account_type, a.account_status,
         a.currency_code, a.current_balance, fx.to_usd,
         ROUND(a.current_balance * fx.to_usd, 2) AS balance_usd
  FROM raw.accounts a
  LEFT JOIN raw.fx_rates fx ON a.currency_code = fx.currency_code
), eligible AS (
  SELECT t.*, c.branch_id, c.customer_segment
  FROM typed t
  JOIN raw.customers c ON c.customer_id = t.customer_id
  WHERE t.account_status <> 'CLOSED'
)
SELECT * FROM eligible;

DROP TABLE IF EXISTS extract.account_balances;
CREATE TABLE extract.account_balances AS
SELECT customer_id, COUNT(*) AS account_count,
       ROUND(SUM(CASE WHEN account_status = 'ACTIVE' THEN balance_usd ELSE 0 END),2) AS active_balance_usd,
       ROUND(SUM(balance_usd),2) AS all_open_balance_usd,
       MAX(CASE WHEN account_status = 'FROZEN' THEN 1 ELSE 0 END) AS has_frozen_account
FROM extract.account_base
GROUP BY customer_id;
