-- 04: Transaction normalization, FX conversion, static filters and second alert table.
DROP TABLE IF EXISTS extract.transaction_base;
CREATE TABLE extract.transaction_base AS
WITH base AS (
  SELECT t.txn_id, t.account_id, a.customer_id, t.txn_date,
         t.txn_type, t.channel, t.amount, t.merchant_region,
         ROUND(t.amount * COALESCE(fx.to_usd,1),2) AS amount_usd
  FROM raw.transactions t
  JOIN raw.accounts a ON a.account_id = t.account_id
  LEFT JOIN raw.fx_rates fx ON fx.currency_code = a.currency_code
  WHERE t.txn_date >= '2026-09-01' AND t.txn_date < '2026-10-01'
), classified AS (
  SELECT *,
         CASE WHEN txn_type = 'CREDIT' THEN amount_usd ELSE -amount_usd END AS signed_amount_usd,
         CASE WHEN merchant_region = 'FOREIGN' OR channel = 'WIRE' OR amount_usd >= 10000
              THEN 1 ELSE 0 END AS suspicious_signal
  FROM base
)
SELECT * FROM classified;

DROP TABLE IF EXISTS extract.transaction_alerts;
CREATE TABLE extract.transaction_alerts AS
SELECT txn_id, customer_id, txn_date, channel, amount_usd,
       CASE WHEN merchant_region = 'FOREIGN' THEN 'CROSS_BORDER'
            WHEN amount_usd >= 10000 THEN 'LARGE_TRANSACTION'
            WHEN channel = 'WIRE' THEN 'WIRE_REVIEW' ELSE 'OTHER' END AS alert_reason
FROM extract.transaction_base
WHERE suspicious_signal = 1;
