-- 02: Customer extraction, deduplication and branch enrichment.
DROP TABLE IF EXISTS extract.customer_base;
CREATE TABLE extract.customer_base AS
WITH ranked_customers AS (
  SELECT customer_id, full_name, branch_id, customer_segment, kyc_status, created_date,
         ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY created_date DESC) AS rn
  FROM raw.customers
), customer_joined AS (
  SELECT c.customer_id, c.full_name, c.branch_id, b.branch_name, b.region,
         b.risk_region_weight, c.customer_segment, c.kyc_status,
         CASE WHEN c.kyc_status IN ('EXPIRED','PENDING') THEN 1 ELSE 0 END AS kyc_flag
  FROM ranked_customers c
  INNER JOIN raw.branches b ON b.branch_id = c.branch_id
  WHERE c.rn = 1
)
SELECT * FROM customer_joined;
