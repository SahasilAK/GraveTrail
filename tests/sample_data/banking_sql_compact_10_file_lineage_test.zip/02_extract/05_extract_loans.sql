-- 05: Loan extraction and delinquency aggregate; two permanent targets.
DROP TABLE IF EXISTS extract.loan_base;
CREATE TABLE extract.loan_base AS
SELECT l.loan_id, l.account_id, a.customer_id, l.principal,
       l.outstanding, l.days_past_due, l.loan_status,
       CASE WHEN days_past_due >= 90 THEN 'DEFAULT_RISK'
            WHEN days_past_due >= 30 THEN 'DELINQUENT' ELSE 'CURRENT' END AS risk_band
FROM raw.loans l
JOIN raw.accounts a ON a.account_id = l.account_id
WHERE l.loan_status = 'OPEN';

DROP TABLE IF EXISTS extract.loan_summary;
CREATE TABLE extract.loan_summary AS
SELECT customer_id,
       COUNT(*) AS active_loans,
       SUM(outstanding) AS outstanding_principal,
       MAX(days_past_due) AS max_days_past_due,
       SUM(CASE WHEN days_past_due >= 30 THEN outstanding ELSE 0 END) AS delinquent_exposure
FROM extract.loan_base
GROUP BY customer_id;
