-- 09: Three final reporting outputs; shared and cross-layer lineage.
DROP TABLE IF EXISTS publish.executive_risk_summary;
CREATE TABLE publish.executive_risk_summary AS
WITH branch_metrics AS (
  SELECT r.branch_id, r.branch_name, r.region, r.total_customers,
         r.high_risk_customers, r.avg_risk_score,
         COALESCE(e.total_deposits_usd,0) AS deposits_usd,
         COALESCE(e.total_loans_usd,0) AS loans_usd,
         COALESCE(e.delinquent_loans_usd,0) AS delinquent_loans_usd
  FROM mart.branch_risk r
  JOIN core.branch_exposure e ON e.branch_id=r.branch_id
), scorecard AS (
  SELECT *, ROUND(loans_usd / NULLIF(deposits_usd,0),4) AS loan_to_deposit_ratio,
         CASE WHEN high_risk_customers >= 2 THEN 'ESCALATE' ELSE 'MONITOR' END AS action
  FROM branch_metrics
)
SELECT s.*, b.risk_region_weight,
       (SELECT COUNT(*) FROM mart.customer_risk c
         WHERE c.branch_id=s.branch_id AND c.risk_tier='MEDIUM') AS medium_risk_customers
FROM scorecard s
JOIN raw.branches b ON b.branch_id=s.branch_id;

DROP TABLE IF EXISTS publish.high_risk_customers;
CREATE TABLE publish.high_risk_customers AS
SELECT r.customer_id, c.full_name, c.region, r.branch_id,
       r.risk_score, r.risk_tier, r.watchlisted_flag, r.overdue_exposure_usd,
       CASE WHEN r.watchlisted_flag=1 THEN 'WATCHLIST_REVIEW'
            WHEN r.max_days_past_due >= 90 THEN 'COLLECTIONS_ESCALATION'
            ELSE 'ENHANCED_DUE_DILIGENCE' END AS next_action
FROM mart.customer_risk r
JOIN extract.customer_base c ON c.customer_id=r.customer_id
WHERE r.risk_tier='HIGH';

DROP TABLE IF EXISTS publish.regulatory_liquidity_snapshot;
CREATE TABLE publish.regulatory_liquidity_snapshot AS
SELECT b.branch_id, b.branch_name,
       e.total_deposits_usd, e.total_loans_usd,
       r.high_risk_customers,
       ROUND(e.total_deposits_usd - e.total_loans_usd,2) AS funding_gap_usd,
       '2026-09-30' AS reporting_date
FROM core.branch_exposure e
JOIN mart.branch_risk r ON r.branch_id=e.branch_id
JOIN raw.branches b ON b.branch_id=e.branch_id;
