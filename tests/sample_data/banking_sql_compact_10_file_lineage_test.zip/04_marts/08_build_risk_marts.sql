-- 08: Enterprise risk mart combines exposures, activity, alerts and watchlist.
DROP TABLE IF EXISTS mart.customer_risk;
CREATE TABLE mart.customer_risk AS
WITH inputs AS (
  SELECT e.customer_id, e.full_name, e.branch_id, e.customer_segment,
         e.deposits_usd, e.loans_usd, e.overdue_exposure_usd,
         e.net_position_usd, e.max_days_past_due, e.kyc_flag,
         COALESCE(t.suspicious_transaction_count,0) AS suspicious_transaction_count,
         COALESCE(t.total_alerts,0) AS total_alerts,
         COALESCE(s.watchlisted_flag,0) AS watchlisted_flag,
         COALESCE(w.severity,0) AS watchlist_severity,
         COALESCE(t.branch_volume_rank,9999) AS branch_volume_rank
  FROM core.customer_exposure e
  LEFT JOIN core.transaction_behavior t ON t.customer_id=e.customer_id
  LEFT JOIN core.suspicious_customers s ON s.customer_id=e.customer_id
  LEFT JOIN raw.watchlist w ON w.customer_id=e.customer_id
), scored AS (
  SELECT *,
      (kyc_flag * 15 + CASE WHEN max_days_past_due >= 90 THEN 35
                            WHEN max_days_past_due >= 30 THEN 20 ELSE 0 END
       + MIN(suspicious_transaction_count * 3, 18)
       + watchlist_severity * 8
       + CASE WHEN overdue_exposure_usd > 10000 THEN 10 ELSE 0 END) AS risk_score
  FROM inputs
)
SELECT *, CASE WHEN risk_score >= 55 THEN 'HIGH'
               WHEN risk_score >= 25 THEN 'MEDIUM' ELSE 'LOW' END AS risk_tier
FROM scored;

DROP TABLE IF EXISTS mart.branch_risk;
CREATE TABLE mart.branch_risk AS
SELECT b.branch_id, b.branch_name, b.region,
       COUNT(r.customer_id) AS total_customers,
       SUM(CASE WHEN r.risk_tier='HIGH' THEN 1 ELSE 0 END) AS high_risk_customers,
       ROUND(AVG(r.risk_score),2) AS avg_risk_score,
       SUM(r.loans_usd) AS outstanding_loans_usd
FROM raw.branches b
LEFT JOIN mart.customer_risk r ON r.branch_id=b.branch_id
GROUP BY b.branch_id, b.branch_name, b.region;
