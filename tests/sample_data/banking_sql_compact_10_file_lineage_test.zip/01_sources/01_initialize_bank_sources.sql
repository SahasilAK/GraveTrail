-- 01: Source initialization, static reference data, bulk inserts and transactional facts.
-- SQLite-specific initialization: attached in-memory schemas persist during this session.
-- Execute scripts 01-09 IN ORDER using ONE SQLite connection.
ATTACH DATABASE ':memory:' AS raw;
ATTACH DATABASE ':memory:' AS extract;
ATTACH DATABASE ':memory:' AS core;
ATTACH DATABASE ':memory:' AS mart;
ATTACH DATABASE ':memory:' AS publish;

CREATE TABLE raw.branches (
  branch_id INTEGER PRIMARY KEY, branch_name TEXT NOT NULL,
  region TEXT NOT NULL, risk_region_weight REAL NOT NULL
);
INSERT INTO raw.branches (branch_id, branch_name, region, risk_region_weight) VALUES
  (1, 'Harbor Central', 'North', 1.00),
  (2, 'Riverside', 'South', 1.15),
  (3, 'Market Square', 'East', 1.30),
  (4, 'Hill Crest', 'West', 0.90);

CREATE TABLE raw.customers (
  customer_id INTEGER PRIMARY KEY, full_name TEXT NOT NULL,
  branch_id INTEGER NOT NULL, customer_segment TEXT NOT NULL,
  kyc_status TEXT NOT NULL, created_date TEXT NOT NULL
);
INSERT INTO raw.customers (customer_id, full_name, branch_id, customer_segment, kyc_status, created_date) VALUES
  (101,'Asha Menon',1,'RETAIL','VERIFIED','2023-02-18'),
  (102,'Dylan Shah',1,'SME','VERIFIED','2022-08-09'),
  (103,'Leena Nair',2,'RETAIL','PENDING','2024-05-16'),
  (104,'Mateo Silva',2,'PRIVATE','VERIFIED','2021-04-21'),
  (105,'Priya Kumar',3,'SME','EXPIRED','2022-11-01'),
  (106,'Oliver Chen',3,'RETAIL','VERIFIED','2020-09-08'),
  (107,'Nora Khan',4,'PRIVATE','VERIFIED','2022-02-04'),
  (108,'Ethan Reed',4,'RETAIL','PENDING','2025-01-08'),
  (109,'Maya Patel',1,'SME','VERIFIED','2023-06-07'),
  (110,'Arun Joseph',2,'RETAIL','VERIFIED','2022-03-20'),
  (111,'Sofia Rahman',3,'PRIVATE','EXPIRED','2019-07-24'),
  (112,'Theo Iyer',4,'SME','VERIFIED','2021-12-15');

CREATE TABLE raw.accounts (
  account_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL,
  account_type TEXT NOT NULL, account_status TEXT NOT NULL,
  currency_code TEXT NOT NULL, current_balance REAL NOT NULL
);
INSERT INTO raw.accounts (account_id, customer_id, account_type, account_status, currency_code, current_balance) VALUES
  (1001,101,'SAVINGS','ACTIVE','USD',9500),
  (1002,101,'CHECKING','ACTIVE','USD',3200),
  (1003,102,'BUSINESS','ACTIVE','USD',175000),
  (1004,103,'SAVINGS','ACTIVE','EUR',4250),
  (1005,104,'INVESTMENT','ACTIVE','USD',255000),
  (1006,105,'BUSINESS','FROZEN','USD',42000),
  (1007,106,'CHECKING','ACTIVE','USD',8600),
  (1008,107,'INVESTMENT','ACTIVE','EUR',185000),
  (1009,108,'SAVINGS','ACTIVE','USD',570),
  (1010,109,'BUSINESS','ACTIVE','USD',98000),
  (1011,110,'CHECKING','ACTIVE','USD',6750),
  (1012,111,'INVESTMENT','ACTIVE','USD',325000),
  (1013,112,'BUSINESS','ACTIVE','EUR',120000),
  (1014,103,'CHECKING','CLOSED','USD',0),
  (1015,105,'SAVINGS','ACTIVE','USD',1300),
  (1016,110,'SAVINGS','ACTIVE','USD',19400);

CREATE TABLE raw.fx_rates (currency_code TEXT PRIMARY KEY, to_usd REAL NOT NULL);
INSERT INTO raw.fx_rates(currency_code,to_usd) VALUES ('USD',1.0),('EUR',1.08);

CREATE TABLE raw.loans (
  loan_id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL,
  principal REAL NOT NULL, outstanding REAL NOT NULL,
  days_past_due INTEGER NOT NULL, loan_status TEXT NOT NULL
);
INSERT INTO raw.loans (loan_id,account_id,principal,outstanding,days_past_due,loan_status) VALUES
  (2001,1001,12000,6200,0,'OPEN'),(2002,1003,85000,70000,21,'OPEN'),
  (2003,1004,18000,15700,63,'OPEN'),(2004,1005,150000,88000,0,'OPEN'),
  (2005,1006,25000,14500,95,'OPEN'),(2006,1008,70000,48000,0,'OPEN'),
  (2007,1009,15000,13250,45,'OPEN'),(2008,1010,60000,53000,8,'OPEN'),
  (2009,1012,90000,30000,0,'CLOSED'),(2010,1013,110000,104000,31,'OPEN');

CREATE TABLE raw.watchlist (customer_id INTEGER PRIMARY KEY, watch_reason TEXT, severity INTEGER);
INSERT INTO raw.watchlist VALUES
  (105,'ADVERSE_MEDIA',3),(108,'UNUSUAL_ACTIVITY',2),(111,'REVIEW_REQUIRED',2);

-- Generate 192 deterministic synthetic transaction events using a recursive CTE.
CREATE TABLE raw.transactions (
  txn_id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL,
  txn_date TEXT NOT NULL, txn_type TEXT NOT NULL,
  channel TEXT NOT NULL, amount REAL NOT NULL, merchant_region TEXT NOT NULL
);
WITH RECURSIVE counter(n) AS (
    SELECT 1 UNION ALL SELECT n + 1 FROM counter WHERE n < 192
)
INSERT INTO raw.transactions (txn_id, account_id, txn_date, txn_type, channel, amount, merchant_region)
SELECT n,
       1001 + ((n * 7) % 16),
       date('2026-09-01', '+' || (n % 30) || ' days'),
       CASE WHEN n % 5 = 0 THEN 'CREDIT' ELSE 'DEBIT' END,
       CASE WHEN n % 11 = 0 THEN 'WIRE' WHEN n % 3 = 0 THEN 'ATM' ELSE 'CARD' END,
       CAST((60 + (n * 137) % 12000) AS REAL),
       CASE WHEN n % 9 = 0 THEN 'FOREIGN' ELSE 'DOMESTIC' END
FROM counter;
