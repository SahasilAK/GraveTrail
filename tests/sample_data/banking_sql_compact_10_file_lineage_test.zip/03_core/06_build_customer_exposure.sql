-- 06: Multi-hop financial exposures joining four extracted datasets + branches.
DROP TABLE IF EXISTS core.customer_exposure;
CREATE TABLE core.customer_exposure AS
WITH account_rollup AS (
  SELECT customer_id, active_balance_usd, account_count, has_frozen_account
  FROM extract.account_balances
), loan_rollup AS (
  SELECT customer_id, active_loans, outstanding_principal,
         delinquent_exposure, max_days_past_due
  FROM extract.loan_summary
), monthly_flow AS (
  SELECT customer_id,
         ROUND(SUM(CASE WHEN txn_type='CREDIT' THEN amount_usd ELSE 0 END),2) AS inflows_usd,
         ROUND(SUM(CASE WHEN txn_type='DEBIT' THEN amount_usd ELSE 0 END),2) AS outflows_usd
  FROM extract.transaction_base
  GROUP BY customer_id
), combined AS (
  SELECT c.customer_id, c.full_name, c.branch_id, c.customer_segment, c.kyc_flag,
         c.risk_region_weight,
         COALESCE(a.account_count,0) AS account_count,
         COALESCE(a.active_balance_usd,0) AS deposits_usd,
         COALESCE(a.has_frozen_account,0) AS frozen_flag,
         COALESCE(l.outstanding_principal,0) AS loans_usd,
         COALESCE(l.delinquent_exposure,0) AS overdue_exposure_usd,
         COALESCE(l.max_days_past_due,0) AS max_days_past_due,
         COALESCE(f.inflows_usd,0) AS monthly_inflows_usd,
         COALESCE(f.outflows_usd,0) AS monthly_outflows_usd
  FROM extract.customer_base c
  LEFT JOIN account_rollup a ON a.customer_id=c.customer_id
  LEFT JOIN loan_rollup l ON l.customer_id=c.customer_id
  LEFT JOIN monthly_flow f ON f.customer_id=c.customer_id
)
SELECT *, ROUND(deposits_usd - loans_usd,2) AS net_position_usd,
       ROUND(loans_usd / NULLIF(deposits_usd,0),4) AS loan_to_deposit_ratio
FROM combined;

DROP TABLE IF EXISTS core.branch_exposure;
CREATE TABLE core.branch_exposure AS
SELECT b.branch_id, b.branch_name, b.region,
       COUNT(e.customer_id) AS customer_count,
       SUM(e.deposits_usd) AS total_deposits_usd,
       SUM(e.loans_usd) AS total_loans_usd,
       SUM(e.overdue_exposure_usd) AS delinquent_loans_usd
FROM raw.branches b
LEFT JOIN core.customer_exposure e ON e.branch_id=b.branch_id
GROUP BY b.branch_id, b.branch_name, b.region;
