-- 07: Local temporary table + multi-output permanent tables, EXISTS and window logic.
DROP TABLE IF EXISTS temp.work_transaction_flags;
CREATE TEMP TABLE work_transaction_flags AS
WITH by_customer AS (
  SELECT t.customer_id, COUNT(*) AS transaction_count,
         ROUND(SUM(t.amount_usd),2) AS gross_volume_usd,
         MAX(t.amount_usd) AS largest_transaction_usd,
         SUM(t.suspicious_signal) AS suspicious_transaction_count,
         SUM(CASE WHEN t.txn_type = 'CREDIT' THEN 1 ELSE 0 END) AS credit_count,
         SUM(CASE WHEN t.txn_type = 'DEBIT' THEN 1 ELSE 0 END) AS debit_count
  FROM extract.transaction_base t
  GROUP BY t.customer_id
)
SELECT *, CASE WHEN largest_transaction_usd > 9000 OR suspicious_transaction_count >= 3
               THEN 1 ELSE 0 END AS behavioral_flag
FROM by_customer;

DROP TABLE IF EXISTS core.transaction_behavior;
CREATE TABLE core.transaction_behavior AS
WITH alerts AS (
  SELECT customer_id, COUNT(*) AS total_alerts
  FROM extract.transaction_alerts
  GROUP BY customer_id
), enriched AS (
  SELECT c.customer_id, c.branch_id, c.customer_segment, a.account_count,
         COALESCE(w.transaction_count,0) AS transaction_count,
         COALESCE(w.gross_volume_usd,0) AS gross_volume_usd,
         COALESCE(w.largest_transaction_usd,0) AS largest_transaction_usd,
         COALESCE(w.suspicious_transaction_count,0) AS suspicious_transaction_count,
         COALESCE(al.total_alerts,0) AS total_alerts,
         COALESCE(w.behavioral_flag,0) AS behavioral_flag,
         e.max_days_past_due,
         DENSE_RANK() OVER (PARTITION BY c.branch_id
                            ORDER BY COALESCE(w.gross_volume_usd,0) DESC) AS branch_volume_rank
  FROM extract.customer_base c
  LEFT JOIN extract.account_balances a ON a.customer_id=c.customer_id
  LEFT JOIN temp.work_transaction_flags w ON w.customer_id=c.customer_id
  LEFT JOIN alerts al ON al.customer_id=c.customer_id
  LEFT JOIN core.customer_exposure e ON e.customer_id=c.customer_id
)
SELECT * FROM enriched;

DROP TABLE IF EXISTS core.suspicious_customers;
CREATE TABLE core.suspicious_customers AS
SELECT t.customer_id, t.total_alerts, t.suspicious_transaction_count,
       t.behavioral_flag,
       CASE WHEN EXISTS (SELECT 1 FROM raw.watchlist w WHERE w.customer_id=t.customer_id)
            THEN 1 ELSE 0 END AS watchlisted_flag
FROM core.transaction_behavior t
WHERE t.behavioral_flag=1 OR t.total_alerts>=2
   OR EXISTS (SELECT 1 FROM raw.watchlist w WHERE w.customer_id=t.customer_id);
