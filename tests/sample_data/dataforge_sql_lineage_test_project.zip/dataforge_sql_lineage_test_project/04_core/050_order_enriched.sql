-- LINEAGE TEST | stage=core | target=core.order_enriched
-- Direct persistent source assets: stg.orders_clean, stg.order_items_clean, core.customer_profile
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE core.order_enriched AS
WITH joined_records AS (
    SELECT
        a.entity_id AS entity_id,
        a.customer_id AS customer_id,
        a.order_id AS order_id,
        a.product_id AS product_id,
        a.event_date AS event_date,
        (a.amount + COALESCE(b.amount, 0) + COALESCE(c.amount, 0)) AS amount,
        a.status AS status,
        a.channel AS channel,
        a.region AS region,
        (a.quantity + COALESCE(b.quantity, 0) + COALESCE(c.quantity, 0)) AS quantity,
        a.updated_at AS updated_at
    FROM stg.orders_clean AS a
    LEFT JOIN stg.order_items_clean AS b ON a.customer_id = b.customer_id
    LEFT JOIN core.customer_profile AS c ON a.customer_id = c.customer_id
    WHERE a.customer_id IS NOT NULL
),
classified AS (
    SELECT *, CASE WHEN amount >= 600 THEN 'HIGH'
                   WHEN amount >= 200 THEN 'MEDIUM'
                   ELSE 'LOW' END AS value_band
    FROM joined_records
)
SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at, value_band
FROM classified;
