-- LINEAGE TEST | stage=stg | target=stg.orders_clean
-- Direct persistent source assets: ext.orders_raw
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE stg.orders_clean AS
WITH normalized AS (
    SELECT
        entity_id, customer_id, order_id, product_id,
        CAST(event_date AS DATE) AS event_date,
        CAST(amount AS DECIMAL(18, 2)) AS amount,
        UPPER(TRIM(status)) AS status,
        LOWER(TRIM(channel)) AS channel,
        LOWER(TRIM(region)) AS region,
        COALESCE(quantity, 0) AS quantity,
        CAST(updated_at AS TIMESTAMP) AS updated_at
    FROM ext.orders_raw
),
ranked AS (
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY entity_id ORDER BY updated_at DESC
    ) AS record_rank
    FROM normalized
)
SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
FROM ranked
WHERE record_rank = 1;
