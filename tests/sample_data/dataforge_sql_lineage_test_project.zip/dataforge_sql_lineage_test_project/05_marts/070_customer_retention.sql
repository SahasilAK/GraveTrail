-- LINEAGE TEST | stage=mart | target=mart.customer_retention
-- Direct persistent source assets: core.customer_360, core.subscription_revenue
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE mart.customer_retention AS
WITH combined AS (
    SELECT
        a.entity_id AS entity_id,
        a.customer_id AS customer_id,
        a.order_id AS order_id,
        a.product_id AS product_id,
        a.event_date AS event_date,
        (a.amount + COALESCE(b.amount, 0)) AS amount,
        a.status AS status,
        a.channel AS channel,
        a.region AS region,
        (a.quantity + COALESCE(b.quantity, 0)) AS quantity,
        a.updated_at AS updated_at
    FROM core.customer_360 AS a
    LEFT JOIN core.subscription_revenue AS b ON a.customer_id = b.customer_id
),
metrics AS (
    SELECT *, ROUND(amount / NULLIF(quantity, 0), 2) AS unit_metric
    FROM combined
)
SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at, unit_metric
FROM metrics
WHERE customer_id IS NOT NULL;
