#!/usr/bin/env python3
"""Execute SQL fixtures in dependency order against a local DuckDB database.

Usage:
    pip install duckdb
    python tools/run_sql.py
    python tools/run_sql.py --database /tmp/lineage_fixture.duckdb
"""
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--database', default=':memory:', help='DuckDB database path; default in-memory')
args = parser.parse_args()
try:
    import duckdb
except ImportError as exc:
    raise SystemExit('Install optional test dependency: pip install duckdb') from exc
root = Path(__file__).resolve().parents[1]
paths = [line.strip() for line in (root / 'RUN_ORDER.txt').read_text().splitlines()
         if line.strip() and not line.startswith('#')]
connection = duckdb.connect(args.database)
for index, path in enumerate(paths, 1):
    source = root / path
    try:
        connection.execute(source.read_text(encoding='utf-8'))
    except Exception as exc:
        raise SystemExit(f'ERROR at {index}/{len(paths)}: {path}: {exc}') from exc
    print(f'{index:03d}/{len(paths):03d}  {path}')
print(f'PASS: Executed {len(paths)} SQL scripts; final rows =',
      connection.execute('SELECT COUNT(*) FROM pub.all_kpis').fetchone()[0])
connection.close()
