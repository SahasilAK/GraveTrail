-- LINEAGE TEST | stage=rpt | target=rpt.product_leadership
-- Direct persistent source assets: mart.product_performance, mart.inventory_coverage
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE rpt.product_leadership AS
WITH reporting_base AS (
    SELECT
        a.entity_id AS entity_id,
        a.customer_id AS customer_id,
        a.order_id AS order_id,
        a.product_id AS product_id,
        a.event_date AS event_date,
        (a.amount + COALESCE(b.amount, 0)) AS amount,
        a.status AS status,
        a.channel AS channel,
        a.region AS region,
        (a.quantity + COALESCE(b.quantity, 0)) AS quantity,
        a.updated_at AS updated_at
    FROM mart.product_performance AS a
    LEFT JOIN mart.inventory_coverage AS b ON a.customer_id = b.customer_id
)
SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at,
       CASE WHEN amount >= 500 THEN 'PRIORITY' ELSE 'STANDARD' END AS reporting_tier
FROM reporting_base;
