-- LINEAGE TEST | stage=rpt | target=rpt.finance
-- Direct persistent source assets: mart.revenue_daily, mart.finance_reconciliation
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE rpt.finance AS
WITH reporting_base AS (
    SELECT
        a.entity_id AS entity_id,
        a.customer_id AS customer_id,
        a.order_id AS order_id,
        a.product_id AS product_id,
        a.event_date AS event_date,
        (a.amount + COALESCE(b.amount, 0)) AS amount,
        a.status AS status,
        a.channel AS channel,
        a.region AS region,
        (a.quantity + COALESCE(b.quantity, 0)) AS quantity,
        a.updated_at AS updated_at
    FROM mart.revenue_daily AS a
    LEFT JOIN mart.finance_reconciliation AS b ON a.customer_id = b.customer_id
)
SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at,
       CASE WHEN amount >= 500 THEN 'PRIORITY' ELSE 'STANDARD' END AS reporting_tier
FROM reporting_base;
