-- LINEAGE TEST | stage=pub | target=pub.commercial_pack
-- Direct persistent source assets: rpt.product_leadership, rpt.growth
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE pub.commercial_pack AS
WITH publication_base AS (
    SELECT
        a.entity_id AS entity_id,
        a.customer_id AS customer_id,
        a.order_id AS order_id,
        a.product_id AS product_id,
        a.event_date AS event_date,
        (a.amount + COALESCE(b.amount, 0)) AS amount,
        a.status AS status,
        a.channel AS channel,
        a.region AS region,
        (a.quantity + COALESCE(b.quantity, 0)) AS quantity,
        a.updated_at AS updated_at
    FROM rpt.product_leadership AS a
    LEFT JOIN rpt.growth AS b ON a.customer_id = b.customer_id
),
published AS (
    SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at,
           CURRENT_TIMESTAMP AS published_at
    FROM publication_base
)
SELECT * FROM published;
