-- LINEAGE TEST | stage=pub | target=pub.all_kpis
-- Direct persistent source assets: rpt.daily_ops, rpt.growth, rpt.finance, rpt.customer_experience, rpt.product_leadership, rpt.executive_summary
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE pub.all_kpis AS
WITH publication_base AS (
    SELECT
        a.entity_id AS entity_id,
        a.customer_id AS customer_id,
        a.order_id AS order_id,
        a.product_id AS product_id,
        a.event_date AS event_date,
        (a.amount + COALESCE(b.amount, 0) + COALESCE(c.amount, 0) + COALESCE(d.amount, 0) + COALESCE(e.amount, 0) + COALESCE(f.amount, 0)) AS amount,
        a.status AS status,
        a.channel AS channel,
        a.region AS region,
        (a.quantity + COALESCE(b.quantity, 0) + COALESCE(c.quantity, 0) + COALESCE(d.quantity, 0) + COALESCE(e.quantity, 0) + COALESCE(f.quantity, 0)) AS quantity,
        a.updated_at AS updated_at
    FROM rpt.daily_ops AS a
    LEFT JOIN rpt.growth AS b ON a.customer_id = b.customer_id
    LEFT JOIN rpt.finance AS c ON a.customer_id = c.customer_id
    LEFT JOIN rpt.customer_experience AS d ON a.customer_id = d.customer_id
    LEFT JOIN rpt.product_leadership AS e ON a.customer_id = e.customer_id
    LEFT JOIN rpt.executive_summary AS f ON a.customer_id = f.customer_id
),
published AS (
    SELECT entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at,
           CURRENT_TIMESTAMP AS published_at
    FROM publication_base
)
SELECT * FROM published;
