-- LINEAGE TEST | stage=src | target=src.payments
-- Direct persistent source assets: none (seed source)
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE src.payments AS
SELECT
    CAST(entity_id AS BIGINT) AS entity_id,
    CAST(customer_id AS BIGINT) AS customer_id,
    CAST(order_id AS BIGINT) AS order_id,
    CAST(product_id AS BIGINT) AS product_id,
    CAST(event_date AS DATE) AS event_date,
    CAST(amount AS DECIMAL(18,2)) AS amount,
    CAST(status AS VARCHAR) AS status,
    CAST(channel AS VARCHAR) AS channel,
    CAST(region AS VARCHAR) AS region,
    CAST(quantity AS INTEGER) AS quantity,
    CAST(updated_at AS TIMESTAMP) AS updated_at
FROM (VALUES
    (601, 101, 1001, 501, '2026-01-01', 84.25, 'active', 'web', 'north', 2, '2026-01-01 09:06:00'),
    (602, 102, 1002, 502, '2026-01-02', 101.50, 'paid', 'mobile', 'south', 3, '2026-01-02 09:06:00'),
    (603, 103, 1003, 503, '2026-01-03', 118.75, 'pending', 'partner', 'east', 4, '2026-01-03 09:06:00'),
    (604, 104, 1004, 504, '2026-01-04', 136.00, 'active', 'store', 'west', 5, '2026-01-04 09:06:00')
) AS seed(entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at);
