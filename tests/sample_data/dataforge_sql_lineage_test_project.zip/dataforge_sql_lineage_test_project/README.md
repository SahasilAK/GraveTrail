# DataForge — SQL Lineage Test Project

This ZIP contains a **synthetic, interconnected multi-stage ecommerce/finance ETL project** for stress-testing a data-engineering application's file ingestion, table-level lineage, file tracing, graph explorer, direct table dependencies, and upstream/downstream traversals.

**Quick stats:** 85 output tables · 85 independent transformation/source scripts + 1 setup file · 128 logical direct edges · 128 physical edges · 16 seed source tables · 7 pipeline layers · final public targets `pub.board_pack`, `pub.operations_pack`, `pub.commercial_pack`, `pub.all_kpis`.

## Layer layout

| Folder | Tables | Purpose |
|---|---:|---|
| `01_sources/` | 16 | Synthetic source data |
| `02_extractions/` | 16 | Single-source extraction |
| `03_staging/` | 16 | Standardization and intermediate cleanup |
| `04_core/` | 15 | Multi-source business transformations |
| `05_marts/` | 12 | Data marts combining core models |
| `06_reporting/` | 6 | Reporting datasets |
| `07_published/` | 4 | Published final outputs |

## How to test your lineage app

1. Import the ZIP **or** unzip and select its root folder. Select only `.sql` extensions.
2. Run source inventory and lineage extraction. The app should see **86 `sql` files** including the bootstrap, and **85 persistent tables** (not counting database schema definitions).
3. Search for `pub.all_kpis` and inspect upstream lineage across `pub -> rpt -> mart -> core -> stg -> ext -> src`.
4. Search for `src.customers` and inspect all downstream consumers.
5. Search for `core.customer_360`, `core.payment_reconciliation`, and `mart.executive_kpis` to check multi-source joins.
6. Confirm that each dependency links to the exact script in the matching stage folder.
7. Compare **direct table-level lineage** with `expected/direct_lineage_edges.csv`; compare transitive upstream/downstream results with `expected/query_cases.json`.
8. Inspect `expected/table_inventory.csv` and `expected/lineage_manifest.json` for complete ground truth and source-file paths.
9. Do not count commented table names as extra dependencies. Comments are explanatory.

### Important distinctions

- `src.*` are source tables **created with inline test data**, not external files.
- Every other persistent output has at least one input; most `core`, `mart`, `rpt`, and `pub` outputs have **2–6 inputs**.
- Results are expected at **table/file level**. Common test columns (entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at) support direct column usage tests.
- The manifest lists known persistent data dependencies. Parsing should rely on the statements themselves, not on the manifest or comments.
- Dependency evaluation is static. Runtime scheduling/execution order is provided separately in `RUN_ORDER.txt`.

## Running the scripts

SQL-specific behavior:
- SQL targets DuckDB syntax (CREATE OR REPLACE TABLE, named schemas, CTEs and windows).
- Source seed data is synthesized with SQL VALUES; no external CSV is needed.
- All transformations preserve a shared test schema so the complete DAG can be executed.
- Install optional DuckDB to execute: `pip install duckdb`, then `python tools/run_sql.py`.
- For persisted results: `python tools/run_sql.py --database test_fixture.duckdb` (store the database outside the fixture folder if re-importing).

## Ground-truth files

- `expected/lineage_manifest.json`: complete node catalog, script locations and all logical/physical edges.
- `expected/direct_lineage_edges.csv`: expected direct table-to-table dependencies after collapsing SAS WORK intermediates.
- `expected/physical_lineage_edges.csv`: including SAS temporary WORK datasets, where applicable.
- `expected/query_cases.json`: known direct/transitive upstream/downstream asset sets for 12 reference searches.
- `expected/table_inventory.csv`: expected persistent output tables and paths.
- `RUN_ORDER.txt`: ordered source files for standalone execution.
- `tools/validate_manifest.py`: manifest consistency check (Python standard library only).

Run `python tools/validate_manifest.py` to validate archive consistency after extraction.

## Expected example

Trace `pub.board_pack` back to its reporting sources:

- `pub.board_pack` reads `rpt.executive_summary`, `rpt.finance`, `rpt.growth`.
- `rpt.finance` reads `mart.revenue_daily`, `mart.finance_reconciliation`.
- `mart.finance_reconciliation` reads `core.payment_reconciliation`, `core.currency_adjustments`, `core.subscription_revenue`.
- `core.payment_reconciliation` reads `stg.payments_clean`, `stg.refunds_clean`, `core.order_enriched`.
- `core.order_enriched` reads `stg.orders_clean`, `stg.order_items_clean`, and `core.customer_profile`.
- `core.customer_profile` reads `stg.customers_clean`, `stg.accounts_clean`, and `stg.addresses_clean`.
- Each `stg.*` continues through its respective `ext.*` back to `src.*`.

**Note:** This is a deliberately small-data / large-dependency test. It is not a production data model, and no real customer data is included.
