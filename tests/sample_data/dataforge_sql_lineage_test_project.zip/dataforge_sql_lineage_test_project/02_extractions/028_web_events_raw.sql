-- LINEAGE TEST | stage=ext | target=ext.web_events_raw
-- Direct persistent source assets: src.web_events
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE ext.web_events_raw AS
SELECT
    entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
FROM src.web_events
WHERE customer_id IS NOT NULL
  AND status IS NOT NULL;
