-- LINEAGE TEST | stage=ext | target=ext.inventory_raw
-- Direct persistent source assets: src.inventory
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE ext.inventory_raw AS
SELECT
    entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
FROM src.inventory
WHERE customer_id IS NOT NULL
  AND status IS NOT NULL;
