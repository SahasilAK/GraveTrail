-- LINEAGE TEST | stage=ext | target=ext.refunds_raw
-- Direct persistent source assets: src.refunds
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE ext.refunds_raw AS
SELECT
    entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
FROM src.refunds
WHERE customer_id IS NOT NULL
  AND status IS NOT NULL;
