-- LINEAGE TEST | stage=ext | target=ext.accounts_raw
-- Direct persistent source assets: src.accounts
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE ext.accounts_raw AS
SELECT
    entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
FROM src.accounts
WHERE customer_id IS NOT NULL
  AND status IS NOT NULL;
