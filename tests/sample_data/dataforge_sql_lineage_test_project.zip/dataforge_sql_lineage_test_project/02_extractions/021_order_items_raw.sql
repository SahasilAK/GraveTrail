-- LINEAGE TEST | stage=ext | target=ext.order_items_raw
-- Direct persistent source assets: src.order_items
-- Self-contained statement; dependency order in RUN_ORDER.txt.

CREATE OR REPLACE TABLE ext.order_items_raw AS
SELECT
    entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
FROM src.order_items
WHERE customer_id IS NOT NULL
  AND status IS NOT NULL;
