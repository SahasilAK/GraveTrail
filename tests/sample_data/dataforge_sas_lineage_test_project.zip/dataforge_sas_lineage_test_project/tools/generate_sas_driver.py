#!/usr/bin/env python3
"""Create a SAS driver that includes all fixture programs in dependency order.

Usage:
    python tools/generate_sas_driver.py --output /tmp/dataforge_fixture_driver.sas
Then submit the output script in a licensed SAS environment.
"""
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
paths = [line.strip() for line in (root / 'RUN_ORDER.txt').read_text().splitlines()
         if line.strip() and not line.startswith('#')]
lines = ["/* Generated SAS driver; run in a licensed SAS session. */"]
for path in paths:
    sas_path = str((root / path).resolve()).replace('\\', '/').replace('"', '""')
    lines.append(f'%include "{sas_path}";')
out = Path(args.output).resolve()
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('Created', out, 'with', len(paths), 'ordered includes')
