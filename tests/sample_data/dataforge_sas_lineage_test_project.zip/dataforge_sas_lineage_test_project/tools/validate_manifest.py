#!/usr/bin/env python3
"""Verify fixture files and expected dependencies, using Python stdlib only."""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'expected' / 'lineage_manifest.json').read_text(encoding='utf-8'))
assets = {node['target'] for node in manifest['assets']}
assert len(assets) == manifest['asset_count'], 'Duplicate or missing target assets'
seen = set()
edges = set()
for node in manifest['assets']:
    assert (root / node['script']).is_file(), f"Missing script: {node['script']}"
    for source in node['inputs']:
        assert source in seen, f"Unknown/out-of-order source: {source} -> {node['target']}"
        edges.add((source, node['target']))
    seen.add(node['target'])
expected = set()
with (root / 'expected' / 'direct_lineage_edges.csv').open(newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        expected.add((row['source_asset'], row['target_asset']))
assert edges == expected, 'Manifest/CSV direct lineage edge mismatch'
assert len(edges) == manifest['logical_edge_count'], 'Incorrect edge count'
print(f"PASS: {len(assets)} assets, {len(edges)} expected persistent dependency edges, all scripts present")
