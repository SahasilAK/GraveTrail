/* LINEAGE TEST | stage=src | target=src.accounts
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.accounts;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
201|101|1001|501|2026-01-01|56.25|active|web|north|4|01JAN2026:09:02:00
202|102|1002|502|2026-01-02|73.50|paid|mobile|south|5|02JAN2026:09:02:00
203|103|1003|503|2026-01-03|90.75|pending|partner|east|6|03JAN2026:09:02:00
204|104|1004|504|2026-01-04|108.00|active|store|west|1|04JAN2026:09:02:00
;
run;
