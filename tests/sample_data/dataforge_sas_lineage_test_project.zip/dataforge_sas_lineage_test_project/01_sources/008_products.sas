/* LINEAGE TEST | stage=src | target=src.products
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.products;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
801|101|1001|501|2026-01-01|98.25|active|web|north|4|01JAN2026:09:08:00
802|102|1002|502|2026-01-02|115.50|paid|mobile|south|5|02JAN2026:09:08:00
803|103|1003|503|2026-01-03|132.75|pending|partner|east|6|03JAN2026:09:08:00
804|104|1004|504|2026-01-04|150.00|active|store|west|1|04JAN2026:09:08:00
;
run;
