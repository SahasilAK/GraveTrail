/* LINEAGE TEST | stage=src | target=src.order_items
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.order_items;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
501|101|1001|501|2026-01-01|77.25|active|web|north|1|01JAN2026:09:05:00
502|102|1002|502|2026-01-02|94.50|paid|mobile|south|2|02JAN2026:09:05:00
503|103|1003|503|2026-01-03|111.75|pending|partner|east|3|03JAN2026:09:05:00
504|104|1004|504|2026-01-04|129.00|active|store|west|4|04JAN2026:09:05:00
;
run;
