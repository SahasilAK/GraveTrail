/* LINEAGE TEST | stage=src | target=src.addresses
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.addresses;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
301|101|1001|501|2026-01-01|63.25|active|web|north|5|01JAN2026:09:03:00
302|102|1002|502|2026-01-02|80.50|paid|mobile|south|6|02JAN2026:09:03:00
303|103|1003|503|2026-01-03|97.75|pending|partner|east|1|03JAN2026:09:03:00
304|104|1004|504|2026-01-04|115.00|active|store|west|2|04JAN2026:09:03:00
;
run;
