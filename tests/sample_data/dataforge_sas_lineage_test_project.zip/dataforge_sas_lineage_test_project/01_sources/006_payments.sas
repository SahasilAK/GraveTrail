/* LINEAGE TEST | stage=src | target=src.payments
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.payments;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
601|101|1001|501|2026-01-01|84.25|active|web|north|2|01JAN2026:09:06:00
602|102|1002|502|2026-01-02|101.50|paid|mobile|south|3|02JAN2026:09:06:00
603|103|1003|503|2026-01-03|118.75|pending|partner|east|4|03JAN2026:09:06:00
604|104|1004|504|2026-01-04|136.00|active|store|west|5|04JAN2026:09:06:00
;
run;
