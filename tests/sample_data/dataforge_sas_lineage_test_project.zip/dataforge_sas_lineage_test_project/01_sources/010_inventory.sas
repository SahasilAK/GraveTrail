/* LINEAGE TEST | stage=src | target=src.inventory
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.inventory;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
1001|101|1001|501|2026-01-01|112.25|active|web|north|6|01JAN2026:09:10:00
1002|102|1002|502|2026-01-02|129.50|paid|mobile|south|1|02JAN2026:09:10:00
1003|103|1003|503|2026-01-03|146.75|pending|partner|east|2|03JAN2026:09:10:00
1004|104|1004|504|2026-01-04|164.00|active|store|west|3|04JAN2026:09:10:00
;
run;
