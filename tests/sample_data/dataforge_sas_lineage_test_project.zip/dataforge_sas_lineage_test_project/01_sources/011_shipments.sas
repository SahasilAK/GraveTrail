/* LINEAGE TEST | stage=src | target=src.shipments
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.shipments;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
1101|101|1001|501|2026-01-01|119.25|active|web|north|1|01JAN2026:09:11:00
1102|102|1002|502|2026-01-02|136.50|paid|mobile|south|2|02JAN2026:09:11:00
1103|103|1003|503|2026-01-03|153.75|pending|partner|east|3|03JAN2026:09:11:00
1104|104|1004|504|2026-01-04|171.00|active|store|west|4|04JAN2026:09:11:00
;
run;
