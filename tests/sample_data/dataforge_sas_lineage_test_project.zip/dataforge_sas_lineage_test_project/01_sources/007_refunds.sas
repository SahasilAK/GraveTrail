/* LINEAGE TEST | stage=src | target=src.refunds
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.refunds;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
701|101|1001|501|2026-01-01|91.25|active|web|north|3|01JAN2026:09:07:00
702|102|1002|502|2026-01-02|108.50|paid|mobile|south|4|02JAN2026:09:07:00
703|103|1003|503|2026-01-03|125.75|pending|partner|east|5|03JAN2026:09:07:00
704|104|1004|504|2026-01-04|143.00|active|store|west|6|04JAN2026:09:07:00
;
run;
