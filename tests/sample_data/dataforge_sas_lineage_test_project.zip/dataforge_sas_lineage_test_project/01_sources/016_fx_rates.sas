/* LINEAGE TEST | stage=src | target=src.fx_rates
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.fx_rates;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
1601|101|1001|501|2026-01-01|154.25|active|web|north|6|01JAN2026:09:16:00
1602|102|1002|502|2026-01-02|171.50|paid|mobile|south|1|02JAN2026:09:16:00
1603|103|1003|503|2026-01-03|188.75|pending|partner|east|2|03JAN2026:09:16:00
1604|104|1004|504|2026-01-04|206.00|active|store|west|3|04JAN2026:09:16:00
;
run;
