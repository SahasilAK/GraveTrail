/* LINEAGE TEST | stage=src | target=src.categories
   Direct persistent source assets: none (seed source)
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

data src.categories;
    length status $20 channel $20 region $20;
    infile datalines dlm='|' dsd truncover;
    input entity_id customer_id order_id product_id
          event_date :yymmdd10. amount
          status :$20. channel :$20. region :$20.
          quantity updated_at :datetime19.;
    format event_date yymmdd10. updated_at datetime19.;
datalines;
901|101|1001|501|2026-01-01|105.25|active|web|north|5|01JAN2026:09:09:00
902|102|1002|502|2026-01-02|122.50|paid|mobile|south|6|02JAN2026:09:09:00
903|103|1003|503|2026-01-03|139.75|pending|partner|east|1|03JAN2026:09:09:00
904|104|1004|504|2026-01-04|157.00|active|store|west|2|04JAN2026:09:09:00
;
run;
