/* LINEAGE TEST | stage=core | target=core.order_profitability
   Direct persistent source assets: core.order_enriched, core.product_catalog, core.currency_adjustments
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table core.order_profitability as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 600 then 'HIGH' when calculated amount >= 200 then 'MEDIUM' else 'LOW' end as value_band length=6
    from core.order_enriched as a
    left join core.product_catalog as b on a.customer_id = b.customer_id
    left join core.currency_adjustments as c on a.customer_id = c.customer_id
    where a.customer_id is not null;
quit;
