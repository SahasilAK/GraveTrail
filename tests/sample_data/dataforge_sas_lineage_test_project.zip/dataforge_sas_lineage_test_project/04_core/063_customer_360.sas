/* LINEAGE TEST | stage=core | target=core.customer_360
   Direct persistent source assets: core.customer_profile, core.customer_value, core.engagement_signals, core.support_health
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table core.customer_360 as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0) + coalesce(d.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0) + coalesce(d.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 600 then 'HIGH' when calculated amount >= 200 then 'MEDIUM' else 'LOW' end as value_band length=6
    from core.customer_profile as a
    left join core.customer_value as b on a.customer_id = b.customer_id
    left join core.engagement_signals as c on a.customer_id = c.customer_id
    left join core.support_health as d on a.customer_id = d.customer_id
    where a.customer_id is not null;
quit;
