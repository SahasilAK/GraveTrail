/* LINEAGE TEST | stage=core | target=core.subscription_revenue
   Direct persistent source assets: stg.subscriptions_clean, core.customer_profile
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table core.subscription_revenue as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 600 then 'HIGH' when calculated amount >= 200 then 'MEDIUM' else 'LOW' end as value_band length=6
    from stg.subscriptions_clean as a
    left join core.customer_profile as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
