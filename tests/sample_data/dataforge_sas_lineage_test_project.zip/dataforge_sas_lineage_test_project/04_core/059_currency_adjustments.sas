/* LINEAGE TEST | stage=core | target=core.currency_adjustments
   Direct persistent source assets: stg.fx_rates_clean, core.payment_reconciliation
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table core.currency_adjustments as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 600 then 'HIGH' when calculated amount >= 200 then 'MEDIUM' else 'LOW' end as value_band length=6
    from stg.fx_rates_clean as a
    left join core.payment_reconciliation as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
