/* LINEAGE TEST | stage=core | target=core.fulfillment_risk
   Direct persistent source assets: core.fulfillment_status, core.stock_position, core.support_health
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table core.fulfillment_risk as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 600 then 'HIGH' when calculated amount >= 200 then 'MEDIUM' else 'LOW' end as value_band length=6
    from core.fulfillment_status as a
    left join core.stock_position as b on a.customer_id = b.customer_id
    left join core.support_health as c on a.customer_id = c.customer_id
    where a.customer_id is not null;
quit;
