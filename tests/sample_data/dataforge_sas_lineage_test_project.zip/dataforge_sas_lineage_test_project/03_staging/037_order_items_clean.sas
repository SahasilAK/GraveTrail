/* LINEAGE TEST | stage=stg | target=stg.order_items_clean
   Direct persistent source assets: ext.order_items_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.order_items_raw -> work.tmp_order_items_clean -> stg.order_items_clean.
   Expected simplified edge: ext.order_items_raw -> stg.order_items_clean. */
data work.tmp_order_items_clean;
    set ext.order_items_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_order_items_clean out=stg.order_items_clean nodupkey;
    by entity_id;
run;
