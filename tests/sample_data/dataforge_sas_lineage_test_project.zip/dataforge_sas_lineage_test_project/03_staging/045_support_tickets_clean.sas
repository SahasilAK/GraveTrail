/* LINEAGE TEST | stage=stg | target=stg.support_tickets_clean
   Direct persistent source assets: ext.support_tickets_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.support_tickets_raw -> work.tmp_support_tickets_clean -> stg.support_tickets_clean.
   Expected simplified edge: ext.support_tickets_raw -> stg.support_tickets_clean. */
data work.tmp_support_tickets_clean;
    set ext.support_tickets_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_support_tickets_clean out=stg.support_tickets_clean nodupkey;
    by entity_id;
run;
