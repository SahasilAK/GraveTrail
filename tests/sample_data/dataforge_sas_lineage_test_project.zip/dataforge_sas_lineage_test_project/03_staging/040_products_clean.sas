/* LINEAGE TEST | stage=stg | target=stg.products_clean
   Direct persistent source assets: ext.products_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.products_raw -> work.tmp_products_clean -> stg.products_clean.
   Expected simplified edge: ext.products_raw -> stg.products_clean. */
data work.tmp_products_clean;
    set ext.products_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_products_clean out=stg.products_clean nodupkey;
    by entity_id;
run;
