/* LINEAGE TEST | stage=stg | target=stg.orders_clean
   Direct persistent source assets: ext.orders_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.orders_raw -> work.tmp_orders_clean -> stg.orders_clean.
   Expected simplified edge: ext.orders_raw -> stg.orders_clean. */
data work.tmp_orders_clean;
    set ext.orders_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_orders_clean out=stg.orders_clean nodupkey;
    by entity_id;
run;
