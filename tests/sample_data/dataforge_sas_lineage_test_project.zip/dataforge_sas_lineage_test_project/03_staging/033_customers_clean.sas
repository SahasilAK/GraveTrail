/* LINEAGE TEST | stage=stg | target=stg.customers_clean
   Direct persistent source assets: ext.customers_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.customers_raw -> work.tmp_customers_clean -> stg.customers_clean.
   Expected simplified edge: ext.customers_raw -> stg.customers_clean. */
data work.tmp_customers_clean;
    set ext.customers_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_customers_clean out=stg.customers_clean nodupkey;
    by entity_id;
run;
