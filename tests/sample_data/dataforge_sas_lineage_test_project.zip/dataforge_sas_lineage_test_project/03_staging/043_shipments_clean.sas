/* LINEAGE TEST | stage=stg | target=stg.shipments_clean
   Direct persistent source assets: ext.shipments_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.shipments_raw -> work.tmp_shipments_clean -> stg.shipments_clean.
   Expected simplified edge: ext.shipments_raw -> stg.shipments_clean. */
data work.tmp_shipments_clean;
    set ext.shipments_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_shipments_clean out=stg.shipments_clean nodupkey;
    by entity_id;
run;
