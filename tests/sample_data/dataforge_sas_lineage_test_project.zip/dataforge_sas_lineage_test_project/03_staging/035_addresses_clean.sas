/* LINEAGE TEST | stage=stg | target=stg.addresses_clean
   Direct persistent source assets: ext.addresses_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.addresses_raw -> work.tmp_addresses_clean -> stg.addresses_clean.
   Expected simplified edge: ext.addresses_raw -> stg.addresses_clean. */
data work.tmp_addresses_clean;
    set ext.addresses_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_addresses_clean out=stg.addresses_clean nodupkey;
    by entity_id;
run;
