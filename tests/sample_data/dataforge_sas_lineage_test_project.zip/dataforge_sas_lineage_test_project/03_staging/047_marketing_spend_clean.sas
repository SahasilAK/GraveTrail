/* LINEAGE TEST | stage=stg | target=stg.marketing_spend_clean
   Direct persistent source assets: ext.marketing_spend_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.marketing_spend_raw -> work.tmp_marketing_spend_clean -> stg.marketing_spend_clean.
   Expected simplified edge: ext.marketing_spend_raw -> stg.marketing_spend_clean. */
data work.tmp_marketing_spend_clean;
    set ext.marketing_spend_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_marketing_spend_clean out=stg.marketing_spend_clean nodupkey;
    by entity_id;
run;
