/* LINEAGE TEST | stage=stg | target=stg.web_events_clean
   Direct persistent source assets: ext.web_events_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.web_events_raw -> work.tmp_web_events_clean -> stg.web_events_clean.
   Expected simplified edge: ext.web_events_raw -> stg.web_events_clean. */
data work.tmp_web_events_clean;
    set ext.web_events_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_web_events_clean out=stg.web_events_clean nodupkey;
    by entity_id;
run;
