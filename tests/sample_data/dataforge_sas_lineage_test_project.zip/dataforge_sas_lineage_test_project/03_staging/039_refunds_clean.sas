/* LINEAGE TEST | stage=stg | target=stg.refunds_clean
   Direct persistent source assets: ext.refunds_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.refunds_raw -> work.tmp_refunds_clean -> stg.refunds_clean.
   Expected simplified edge: ext.refunds_raw -> stg.refunds_clean. */
data work.tmp_refunds_clean;
    set ext.refunds_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_refunds_clean out=stg.refunds_clean nodupkey;
    by entity_id;
run;
