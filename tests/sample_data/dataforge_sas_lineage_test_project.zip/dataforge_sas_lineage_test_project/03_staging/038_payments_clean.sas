/* LINEAGE TEST | stage=stg | target=stg.payments_clean
   Direct persistent source assets: ext.payments_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.payments_raw -> work.tmp_payments_clean -> stg.payments_clean.
   Expected simplified edge: ext.payments_raw -> stg.payments_clean. */
data work.tmp_payments_clean;
    set ext.payments_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_payments_clean out=stg.payments_clean nodupkey;
    by entity_id;
run;
