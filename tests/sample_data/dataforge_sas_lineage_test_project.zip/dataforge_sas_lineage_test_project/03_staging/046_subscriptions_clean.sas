/* LINEAGE TEST | stage=stg | target=stg.subscriptions_clean
   Direct persistent source assets: ext.subscriptions_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.subscriptions_raw -> work.tmp_subscriptions_clean -> stg.subscriptions_clean.
   Expected simplified edge: ext.subscriptions_raw -> stg.subscriptions_clean. */
data work.tmp_subscriptions_clean;
    set ext.subscriptions_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_subscriptions_clean out=stg.subscriptions_clean nodupkey;
    by entity_id;
run;
