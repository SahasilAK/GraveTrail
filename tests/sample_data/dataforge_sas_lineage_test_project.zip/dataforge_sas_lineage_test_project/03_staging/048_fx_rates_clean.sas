/* LINEAGE TEST | stage=stg | target=stg.fx_rates_clean
   Direct persistent source assets: ext.fx_rates_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.fx_rates_raw -> work.tmp_fx_rates_clean -> stg.fx_rates_clean.
   Expected simplified edge: ext.fx_rates_raw -> stg.fx_rates_clean. */
data work.tmp_fx_rates_clean;
    set ext.fx_rates_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_fx_rates_clean out=stg.fx_rates_clean nodupkey;
    by entity_id;
run;
