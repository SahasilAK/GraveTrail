/* LINEAGE TEST | stage=stg | target=stg.inventory_clean
   Direct persistent source assets: ext.inventory_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.inventory_raw -> work.tmp_inventory_clean -> stg.inventory_clean.
   Expected simplified edge: ext.inventory_raw -> stg.inventory_clean. */
data work.tmp_inventory_clean;
    set ext.inventory_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_inventory_clean out=stg.inventory_clean nodupkey;
    by entity_id;
run;
