/* LINEAGE TEST | stage=stg | target=stg.accounts_clean
   Direct persistent source assets: ext.accounts_raw
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

/* Deliberately create a temporary WORK dataset to test collapsed lineage.
   Expected physical edges: ext.accounts_raw -> work.tmp_accounts_clean -> stg.accounts_clean.
   Expected simplified edge: ext.accounts_raw -> stg.accounts_clean. */
data work.tmp_accounts_clean;
    set ext.accounts_raw;
    status = upcase(strip(status));
    channel = lowcase(strip(channel));
    region = lowcase(strip(region));
    if missing(customer_id) then delete;
run;

proc sort data=work.tmp_accounts_clean out=stg.accounts_clean nodupkey;
    by entity_id;
run;
