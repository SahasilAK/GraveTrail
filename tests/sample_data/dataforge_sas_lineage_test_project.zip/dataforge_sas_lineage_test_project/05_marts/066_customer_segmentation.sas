/* LINEAGE TEST | stage=mart | target=mart.customer_segmentation
   Direct persistent source assets: core.customer_360, core.customer_value
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table mart.customer_segmentation as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        (calculated amount / max(calculated quantity, 1)) as unit_metric format=12.2
    from core.customer_360 as a
    left join core.customer_value as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
