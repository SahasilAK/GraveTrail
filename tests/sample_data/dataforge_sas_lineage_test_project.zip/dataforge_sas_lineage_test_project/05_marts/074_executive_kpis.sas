/* LINEAGE TEST | stage=mart | target=mart.executive_kpis
   Direct persistent source assets: core.order_profitability, core.customer_value, core.fulfillment_risk, core.campaign_efficiency
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table mart.executive_kpis as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0) + coalesce(d.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0) + coalesce(d.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        (calculated amount / max(calculated quantity, 1)) as unit_metric format=12.2
    from core.order_profitability as a
    left join core.customer_value as b on a.customer_id = b.customer_id
    left join core.fulfillment_risk as c on a.customer_id = c.customer_id
    left join core.campaign_efficiency as d on a.customer_id = d.customer_id
    where a.customer_id is not null;
quit;
