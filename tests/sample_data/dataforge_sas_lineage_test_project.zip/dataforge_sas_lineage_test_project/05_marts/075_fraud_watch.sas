/* LINEAGE TEST | stage=mart | target=mart.fraud_watch
   Direct persistent source assets: core.payment_reconciliation, core.support_health, core.fulfillment_risk
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table mart.fraud_watch as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        (calculated amount / max(calculated quantity, 1)) as unit_metric format=12.2
    from core.payment_reconciliation as a
    left join core.support_health as b on a.customer_id = b.customer_id
    left join core.fulfillment_risk as c on a.customer_id = c.customer_id
    where a.customer_id is not null;
quit;
