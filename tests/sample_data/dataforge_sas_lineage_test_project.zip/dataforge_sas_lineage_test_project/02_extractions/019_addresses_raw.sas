/* LINEAGE TEST | stage=ext | target=ext.addresses_raw
   Direct persistent source assets: src.addresses
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table ext.addresses_raw as
    select entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
    from src.addresses
    where customer_id is not null
      and status is not null;
quit;
