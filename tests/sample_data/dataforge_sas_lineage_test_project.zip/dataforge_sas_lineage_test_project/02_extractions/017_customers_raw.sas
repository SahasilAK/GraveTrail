/* LINEAGE TEST | stage=ext | target=ext.customers_raw
   Direct persistent source assets: src.customers
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table ext.customers_raw as
    select entity_id, customer_id, order_id, product_id, event_date, amount, status, channel, region, quantity, updated_at
    from src.customers
    where customer_id is not null
      and status is not null;
quit;
