/* LINEAGE TEST | stage=pub | target=pub.all_kpis
   Direct persistent source assets: rpt.daily_ops, rpt.growth, rpt.finance, rpt.customer_experience, rpt.product_leadership, rpt.executive_summary
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table pub.all_kpis as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0) + coalesce(d.amount, 0) + coalesce(e.amount, 0) + coalesce(f.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0) + coalesce(d.quantity, 0) + coalesce(e.quantity, 0) + coalesce(f.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        datetime() as published_at format=datetime19.
    from rpt.daily_ops as a
    left join rpt.growth as b on a.customer_id = b.customer_id
    left join rpt.finance as c on a.customer_id = c.customer_id
    left join rpt.customer_experience as d on a.customer_id = d.customer_id
    left join rpt.product_leadership as e on a.customer_id = e.customer_id
    left join rpt.executive_summary as f on a.customer_id = f.customer_id
    where a.customer_id is not null;
quit;
