/* LINEAGE TEST | stage=pub | target=pub.operations_pack
   Direct persistent source assets: rpt.daily_ops, rpt.customer_experience
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table pub.operations_pack as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        datetime() as published_at format=datetime19.
    from rpt.daily_ops as a
    left join rpt.customer_experience as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
