/* LINEAGE TEST | stage=pub | target=pub.board_pack
   Direct persistent source assets: rpt.executive_summary, rpt.finance, rpt.growth
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table pub.board_pack as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        datetime() as published_at format=datetime19.
    from rpt.executive_summary as a
    left join rpt.finance as b on a.customer_id = b.customer_id
    left join rpt.growth as c on a.customer_id = c.customer_id
    where a.customer_id is not null;
quit;
