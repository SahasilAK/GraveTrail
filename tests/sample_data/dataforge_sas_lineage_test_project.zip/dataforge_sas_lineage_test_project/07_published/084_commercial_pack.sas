/* LINEAGE TEST | stage=pub | target=pub.commercial_pack
   Direct persistent source assets: rpt.product_leadership, rpt.growth
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table pub.commercial_pack as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        datetime() as published_at format=datetime19.
    from rpt.product_leadership as a
    left join rpt.growth as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
