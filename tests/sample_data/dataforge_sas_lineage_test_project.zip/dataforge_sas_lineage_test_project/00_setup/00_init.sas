/* Run before other scripts in the SAME SAS session.
   Libraries point to subdirectories under the SAS WORK directory.
   For persistence across SAS sessions, replace df_root with a persistent directory. */
%let df_root=%sysfunc(pathname(work));
options dlcreatedir;
libname src  "&df_root./dataforge_src";
libname ext  "&df_root./dataforge_ext";
libname stg  "&df_root./dataforge_stg";
libname core "&df_root./dataforge_core";
libname mart "&df_root./dataforge_mart";
libname rpt  "&df_root./dataforge_rpt";
libname pub  "&df_root./dataforge_pub";
