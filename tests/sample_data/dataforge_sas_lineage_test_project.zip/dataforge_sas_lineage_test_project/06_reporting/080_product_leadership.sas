/* LINEAGE TEST | stage=rpt | target=rpt.product_leadership
   Direct persistent source assets: mart.product_performance, mart.inventory_coverage
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table rpt.product_leadership as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 500 then 'PRIORITY' else 'STANDARD' end as reporting_tier length=8
    from mart.product_performance as a
    left join mart.inventory_coverage as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
