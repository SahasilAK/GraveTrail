/* LINEAGE TEST | stage=rpt | target=rpt.finance
   Direct persistent source assets: mart.revenue_daily, mart.finance_reconciliation
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table rpt.finance as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 500 then 'PRIORITY' else 'STANDARD' end as reporting_tier length=8
    from mart.revenue_daily as a
    left join mart.finance_reconciliation as b on a.customer_id = b.customer_id
    where a.customer_id is not null;
quit;
