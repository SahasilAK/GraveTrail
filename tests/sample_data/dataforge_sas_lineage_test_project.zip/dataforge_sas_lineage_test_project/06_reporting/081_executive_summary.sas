/* LINEAGE TEST | stage=rpt | target=rpt.executive_summary
   Direct persistent source assets: mart.executive_kpis, mart.finance_reconciliation, mart.marketing_attribution, mart.fraud_watch
   SAS intentionally uses DATA steps and PROC SQL; CREATE OR REPLACE TABLE is not standard SAS PROC SQL.
*/

proc sql;
    create table rpt.executive_summary as
    select a.entity_id, a.customer_id, a.order_id, a.product_id,
        a.event_date format=yymmdd10.,
        (a.amount + coalesce(b.amount, 0) + coalesce(c.amount, 0) + coalesce(d.amount, 0)) as amount,
        a.status, a.channel, a.region,
        (a.quantity + coalesce(b.quantity, 0) + coalesce(c.quantity, 0) + coalesce(d.quantity, 0)) as quantity,
        a.updated_at format=datetime19.,
        case when calculated amount >= 500 then 'PRIORITY' else 'STANDARD' end as reporting_tier length=8
    from mart.executive_kpis as a
    left join mart.finance_reconciliation as b on a.customer_id = b.customer_id
    left join mart.marketing_attribution as c on a.customer_id = c.customer_id
    left join mart.fraud_watch as d on a.customer_id = d.customer_id
    where a.customer_id is not null;
quit;
