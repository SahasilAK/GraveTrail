/* Synthetic bank fixture | business area: current_accounts | layer: seed sources | script: 0002 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.current_accounts_02;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC020001|2026-01-31|7338.25|75.5|21|A
CUS00002|ACC020002|2026-01-31|7591.5|78.0|22|A
CUS00003|ACC020003|2026-01-31|7677.75|115.5|23|A
CUS00004|ACC020004|2026-01-31|7796.0|186.0|24|A
;
run;
