/* Synthetic bank fixture | business area: fraud_detection | layer: seed sources | script: 0003 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.fraud_detection_03;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC030001|2026-01-31|10775.25|81.5|22|A
CUS00002|ACC030002|2026-01-31|10957.5|98.0|23|A
CUS00003|ACC030003|2026-01-31|11215.75|157.5|24|A
CUS00004|ACC030004|2026-01-31|11251.0|174.0|25|A
;
run;
