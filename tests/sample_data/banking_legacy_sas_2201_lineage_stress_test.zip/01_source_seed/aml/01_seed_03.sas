/* Synthetic bank fixture | business area: aml | layer: seed sources | script: 0003 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.aml_03;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC030001|2026-01-31|10757.25|87.5|22|A
CUS00002|ACC030002|2026-01-31|10976.5|78.0|23|A
CUS00003|ACC030003|2026-01-31|11146.75|151.5|24|A
CUS00004|ACC030004|2026-01-31|11447.0|179.0|25|A
;
run;
