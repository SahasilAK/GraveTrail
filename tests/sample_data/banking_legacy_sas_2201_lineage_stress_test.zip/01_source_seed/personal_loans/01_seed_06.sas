/* Synthetic bank fixture | business area: personal_loans | layer: seed sources | script: 0006 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.personal_loans_06;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC060001|2026-01-31|21211.25|44.5|25|A
CUS00002|ACC060002|2026-01-31|21452.5|114.0|26|A
CUS00003|ACC060003|2026-01-31|21633.75|138.5|27|A
CUS00004|ACC060004|2026-01-31|21869.0|162.0|28|A
;
run;
