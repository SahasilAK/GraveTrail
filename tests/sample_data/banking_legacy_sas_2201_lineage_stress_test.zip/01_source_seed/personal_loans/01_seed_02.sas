/* Synthetic bank fixture | business area: personal_loans | layer: seed sources | script: 0002 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.personal_loans_02;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC020001|2026-01-31|7256.25|66.5|21|A
CUS00002|ACC020002|2026-01-31|7370.5|92.0|22|A
CUS00003|ACC020003|2026-01-31|7673.75|147.5|23|A
CUS00004|ACC020004|2026-01-31|7717.0|165.0|24|A
;
run;
