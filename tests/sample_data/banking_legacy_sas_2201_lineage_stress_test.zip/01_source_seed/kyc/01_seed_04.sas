/* Synthetic bank fixture | business area: kyc | layer: seed sources | script: 0004 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.kyc_04;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC040001|2026-01-31|14262.25|77.5|23|A
CUS00002|ACC040002|2026-01-31|14561.5|77.0|24|A
CUS00003|ACC040003|2026-01-31|14606.75|152.5|25|A
CUS00004|ACC040004|2026-01-31|14916.0|167.0|26|A
;
run;
