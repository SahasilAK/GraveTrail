/* Synthetic bank fixture | business area: wealth_management | layer: seed sources | script: 0006 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.wealth_management_06;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC060001|2026-01-31|21382.25|54.5|25|A
CUS00002|ACC060002|2026-01-31|21489.5|125.0|26|A
CUS00003|ACC060003|2026-01-31|21585.75|140.5|27|A
CUS00004|ACC060004|2026-01-31|21724.0|180.0|28|A
;
run;
