/* Synthetic bank fixture | business area: retail_customers | layer: seed sources | script: 0006 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.retail_customers_06;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC060001|2026-01-31|21403.25|85.5|25|A
CUS00002|ACC060002|2026-01-31|21379.5|119.0|26|A
CUS00003|ACC060003|2026-01-31|21763.75|156.5|27|A
CUS00004|ACC060004|2026-01-31|21834.0|151.0|28|A
;
run;
