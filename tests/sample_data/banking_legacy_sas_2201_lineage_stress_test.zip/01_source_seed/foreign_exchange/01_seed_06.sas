/* Synthetic bank fixture | business area: foreign_exchange | layer: seed sources | script: 0006 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.foreign_exchange_06;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC060001|2026-01-31|21314.25|58.5|25|A
CUS00002|ACC060002|2026-01-31|21411.5|101.0|26|A
CUS00003|ACC060003|2026-01-31|21538.75|113.5|27|A
CUS00004|ACC060004|2026-01-31|21903.0|151.0|28|A
;
run;
