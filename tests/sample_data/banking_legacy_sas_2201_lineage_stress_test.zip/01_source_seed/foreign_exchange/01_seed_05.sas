/* Synthetic bank fixture | business area: foreign_exchange | layer: seed sources | script: 0005 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.foreign_exchange_05;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC050001|2026-01-31|17773.25|70.5|24|A
CUS00002|ACC050002|2026-01-31|18015.5|77.0|25|A
CUS00003|ACC050003|2026-01-31|18079.75|133.5|26|A
CUS00004|ACC050004|2026-01-31|18410.0|172.0|27|A
;
run;
