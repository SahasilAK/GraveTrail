/* Synthetic bank fixture | business area: payments | layer: seed sources | script: 0005 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.payments_05;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC050001|2026-01-31|17907.25|55.5|24|A
CUS00002|ACC050002|2026-01-31|17953.5|79.0|25|A
CUS00003|ACC050003|2026-01-31|18281.75|157.5|26|A
CUS00004|ACC050004|2026-01-31|18400.0|175.0|27|A
;
run;
