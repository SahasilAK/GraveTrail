/* Synthetic bank fixture | business area: market_risk | layer: seed sources | script: 0002 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.market_risk_02;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC020001|2026-01-31|7315.25|81.5|21|A
CUS00002|ACC020002|2026-01-31|7436.5|91.0|22|A
CUS00003|ACC020003|2026-01-31|7647.75|162.5|23|A
CUS00004|ACC020004|2026-01-31|7760.0|193.0|24|A
;
run;
