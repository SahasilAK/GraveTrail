/* Synthetic bank fixture | business area: international_transfers | layer: seed sources | script: 0004 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.international_transfers_04;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC040001|2026-01-31|14333.25|66.5|23|A
CUS00002|ACC040002|2026-01-31|14408.5|80.0|24|A
CUS00003|ACC040003|2026-01-31|14742.75|144.5|25|A
CUS00004|ACC040004|2026-01-31|14903.0|190.0|26|A
;
run;
