/* Synthetic bank fixture | business area: international_transfers | layer: seed sources | script: 0006 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.international_transfers_06;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC060001|2026-01-31|21289.25|70.5|25|A
CUS00002|ACC060002|2026-01-31|21402.5|90.0|26|A
CUS00003|ACC060003|2026-01-31|21748.75|141.5|27|A
CUS00004|ACC060004|2026-01-31|21793.0|174.0|28|A
;
run;
