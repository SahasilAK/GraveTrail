/* Synthetic bank fixture | business area: term_deposits | layer: seed sources | script: 0005 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.term_deposits_05;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC050001|2026-01-31|17717.25|46.5|24|A
CUS00002|ACC050002|2026-01-31|17881.5|103.0|25|A
CUS00003|ACC050003|2026-01-31|18083.75|122.5|26|A
CUS00004|ACC050004|2026-01-31|18252.0|190.0|27|A
;
run;
