/* Synthetic bank fixture | business area: branch_operations | layer: seed sources | script: 0002 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.branch_operations_02;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC020001|2026-01-31|7390.25|80.5|21|A
CUS00002|ACC020002|2026-01-31|7419.5|76.0|22|A
CUS00003|ACC020003|2026-01-31|7750.75|138.5|23|A
CUS00004|ACC020004|2026-01-31|7746.0|158.0|24|A
;
run;
