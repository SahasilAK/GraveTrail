/* Synthetic bank fixture | business area: merchant_services | layer: seed sources | script: 0003 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.merchant_services_03;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC030001|2026-01-31|10678.25|46.5|22|A
CUS00002|ACC030002|2026-01-31|10988.5|113.0|23|A
CUS00003|ACC030003|2026-01-31|11139.75|139.5|24|A
CUS00004|ACC030004|2026-01-31|11252.0|154.0|25|A
;
run;
