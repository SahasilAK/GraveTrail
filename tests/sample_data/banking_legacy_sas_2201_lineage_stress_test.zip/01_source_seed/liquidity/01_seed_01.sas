/* Synthetic bank fixture | business area: liquidity | layer: seed sources | script: 0001 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.liquidity_01;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC010001|2026-01-31|3771.25|45.5|20|A
CUS00002|ACC010002|2026-01-31|4024.5|81.0|21|A
CUS00003|ACC010003|2026-01-31|4252.75|132.5|22|A
CUS00004|ACC010004|2026-01-31|4249.0|180.0|23|A
;
run;
