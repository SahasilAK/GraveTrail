/* Synthetic bank fixture | business area: investment_banking | layer: seed sources | script: 0004 */
/* Synthetic, safe DATALINES-only source data; no external systems are contacted by this script. */
data src.investment_banking_04;
length customer_id $16 account_id $16 status_cd $2;
format as_of_date yymmdd10.;
infile datalines dlm='|' dsd truncover;
input customer_id :$16. account_id :$16. as_of_date :yymmdd10.
      balance_amt transaction_amt risk_score status_cd :$2.;
datalines;
CUS00001|ACC040001|2026-01-31|14276.25|46.5|23|A
CUS00002|ACC040002|2026-01-31|14477.5|119.0|24|A
CUS00003|ACC040003|2026-01-31|14712.75|151.5|25|A
CUS00004|ACC040004|2026-01-31|14805.0|151.0|26|A
;
run;
