/* Synthetic bank fixture | business area: treasury | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.treasury_04 out=work.extract_sort_treasury_08 nodupkey;
 by customer_id account_id;
run;
data ext.treasury_extract_08;
 set work.extract_sort_treasury_08;
 if risk_score >= 0;
run;
