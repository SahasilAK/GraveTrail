/* Synthetic bank fixture | business area: kyc | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.kyc_02 out=work.extract_sort_kyc_04 nodupkey;
 by customer_id account_id;
run;
data ext.kyc_extract_04;
 set work.extract_sort_kyc_04;
 if risk_score >= 0;
run;
