/* Synthetic bank fixture | business area: kyc | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.kyc_06 out=work.extract_sort_kyc_12 nodupkey;
 by customer_id account_id;
run;
data ext.kyc_extract_12;
 set work.extract_sort_kyc_12;
 if risk_score >= 0;
run;
