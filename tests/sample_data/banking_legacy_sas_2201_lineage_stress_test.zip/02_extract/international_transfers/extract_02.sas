/* Synthetic bank fixture | business area: international_transfers | layer: extract | script: 0002 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sql;
create table ext.international_transfers_extract_02 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from src.international_transfers_01 as a
where a.balance_amt is not null;
quit;
