/* Synthetic bank fixture | business area: international_transfers | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.international_transfers_02 out=work.extract_sort_international_transfers_04 nodupkey;
 by customer_id account_id;
run;
data ext.international_transfers_extract_04;
 set work.extract_sort_international_transfers_04;
 if risk_score >= 0;
run;
