/* Synthetic bank fixture | business area: international_transfers | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.international_transfers_04 out=work.extract_sort_international_transfers_08 nodupkey;
 by customer_id account_id;
run;
data ext.international_transfers_extract_08;
 set work.extract_sort_international_transfers_08;
 if risk_score >= 0;
run;
