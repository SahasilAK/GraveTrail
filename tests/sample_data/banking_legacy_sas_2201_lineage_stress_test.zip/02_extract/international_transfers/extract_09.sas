/* Synthetic bank fixture | business area: international_transfers | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_international_transfers_09;
 set src.international_transfers_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.international_transfers_extract_09;
 set work.x_international_transfers_09;
 balance_amt = round(balance_amt,0.01);
run;
