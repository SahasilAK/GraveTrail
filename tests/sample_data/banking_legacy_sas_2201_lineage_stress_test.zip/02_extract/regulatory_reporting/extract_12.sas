/* Synthetic bank fixture | business area: regulatory_reporting | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.regulatory_reporting_06 out=work.extract_sort_regulatory_reporting_12 nodupkey;
 by customer_id account_id;
run;
data ext.regulatory_reporting_extract_12;
 set work.extract_sort_regulatory_reporting_12;
 if risk_score >= 0;
run;
