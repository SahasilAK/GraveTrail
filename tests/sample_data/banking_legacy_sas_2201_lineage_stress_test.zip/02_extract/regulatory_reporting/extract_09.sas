/* Synthetic bank fixture | business area: regulatory_reporting | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_regulatory_reporting_09;
 set src.regulatory_reporting_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.regulatory_reporting_extract_09;
 set work.x_regulatory_reporting_09;
 balance_amt = round(balance_amt,0.01);
run;
