/* Synthetic bank fixture | business area: retail_customers | layer: extract | script: 0010 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sql;
create table ext.retail_customers_extract_10 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from src.retail_customers_05 as a
where a.balance_amt is not null;
quit;
