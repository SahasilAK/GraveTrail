/* Synthetic bank fixture | business area: retail_customers | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.retail_customers_02 out=work.extract_sort_retail_customers_04 nodupkey;
 by customer_id account_id;
run;
data ext.retail_customers_extract_04;
 set work.extract_sort_retail_customers_04;
 if risk_score >= 0;
run;
