/* Synthetic bank fixture | business area: retail_customers | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_retail_customers_09;
 set src.retail_customers_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.retail_customers_extract_09;
 set work.x_retail_customers_09;
 balance_amt = round(balance_amt,0.01);
run;
