/* Synthetic bank fixture | business area: term_deposits | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_term_deposits_09;
 set src.term_deposits_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.term_deposits_extract_09;
 set work.x_term_deposits_09;
 balance_amt = round(balance_amt,0.01);
run;
