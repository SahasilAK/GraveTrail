/* Synthetic bank fixture | business area: term_deposits | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.term_deposits_04 out=work.extract_sort_term_deposits_08 nodupkey;
 by customer_id account_id;
run;
data ext.term_deposits_extract_08;
 set work.extract_sort_term_deposits_08;
 if risk_score >= 0;
run;
