/* Synthetic bank fixture | business area: aml | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.aml_06 out=work.extract_sort_aml_12 nodupkey;
 by customer_id account_id;
run;
data ext.aml_extract_12;
 set work.extract_sort_aml_12;
 if risk_score >= 0;
run;
