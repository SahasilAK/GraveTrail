/* Synthetic bank fixture | business area: branch_operations | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.branch_operations_06 out=work.extract_sort_branch_operations_12 nodupkey;
 by customer_id account_id;
run;
data ext.branch_operations_extract_12;
 set work.extract_sort_branch_operations_12;
 if risk_score >= 0;
run;
