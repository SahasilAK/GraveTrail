/* Synthetic bank fixture | business area: savings | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.savings_02 out=work.extract_sort_savings_04 nodupkey;
 by customer_id account_id;
run;
data ext.savings_extract_04;
 set work.extract_sort_savings_04;
 if risk_score >= 0;
run;
