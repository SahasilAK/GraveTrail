/* Synthetic bank fixture | business area: fraud_detection | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.fraud_detection_02 out=work.extract_sort_fraud_detection_04 nodupkey;
 by customer_id account_id;
run;
data ext.fraud_detection_extract_04;
 set work.extract_sort_fraud_detection_04;
 if risk_score >= 0;
run;
