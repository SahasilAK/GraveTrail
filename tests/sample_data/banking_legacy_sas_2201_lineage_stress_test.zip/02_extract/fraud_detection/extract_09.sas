/* Synthetic bank fixture | business area: fraud_detection | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_fraud_detection_09;
 set src.fraud_detection_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.fraud_detection_extract_09;
 set work.x_fraud_detection_09;
 balance_amt = round(balance_amt,0.01);
run;
