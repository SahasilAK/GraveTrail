/* Synthetic bank fixture | business area: current_accounts | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.current_accounts_04 out=work.extract_sort_current_accounts_08 nodupkey;
 by customer_id account_id;
run;
data ext.current_accounts_extract_08;
 set work.extract_sort_current_accounts_08;
 if risk_score >= 0;
run;
