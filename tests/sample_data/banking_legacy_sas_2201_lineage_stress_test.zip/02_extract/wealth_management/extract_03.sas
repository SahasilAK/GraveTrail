/* Synthetic bank fixture | business area: wealth_management | layer: extract | script: 0003 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data ext.wealth_management_extract_03;
 set src.wealth_management_02(keep=customer_id account_id as_of_date balance_amt transaction_amt risk_score status_cd);
 if as_of_date >= '01JAN2025'd;
 retain batch_id 1;
run;
