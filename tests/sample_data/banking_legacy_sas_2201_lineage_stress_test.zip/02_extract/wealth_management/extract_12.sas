/* Synthetic bank fixture | business area: wealth_management | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.wealth_management_06 out=work.extract_sort_wealth_management_12 nodupkey;
 by customer_id account_id;
run;
data ext.wealth_management_extract_12;
 set work.extract_sort_wealth_management_12;
 if risk_score >= 0;
run;
