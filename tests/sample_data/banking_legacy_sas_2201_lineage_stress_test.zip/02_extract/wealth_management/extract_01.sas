/* Synthetic bank fixture | business area: wealth_management | layer: extract | script: 0001 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_wealth_management_01;
 set src.wealth_management_01(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.wealth_management_extract_01;
 set work.x_wealth_management_01;
 balance_amt = round(balance_amt,0.01);
run;
