/* Synthetic bank fixture | business area: payments | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.payments_06 out=work.extract_sort_payments_12 nodupkey;
 by customer_id account_id;
run;
data ext.payments_extract_12;
 set work.extract_sort_payments_12;
 if risk_score >= 0;
run;
