/* Synthetic bank fixture | business area: payments | layer: extract | script: 0007 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data ext.payments_extract_07;
 set src.payments_04(keep=customer_id account_id as_of_date balance_amt transaction_amt risk_score status_cd);
 if as_of_date >= '01JAN2025'd;
 retain batch_id 1;
run;
