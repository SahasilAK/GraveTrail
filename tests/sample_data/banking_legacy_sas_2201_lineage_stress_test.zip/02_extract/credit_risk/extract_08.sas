/* Synthetic bank fixture | business area: credit_risk | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.credit_risk_04 out=work.extract_sort_credit_risk_08 nodupkey;
 by customer_id account_id;
run;
data ext.credit_risk_extract_08;
 set work.extract_sort_credit_risk_08;
 if risk_score >= 0;
run;
