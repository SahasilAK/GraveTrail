/* Synthetic bank fixture | business area: credit_risk | layer: extract | script: 0005 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_credit_risk_05;
 set src.credit_risk_03(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.credit_risk_extract_05;
 set work.x_credit_risk_05;
 balance_amt = round(balance_amt,0.01);
run;
