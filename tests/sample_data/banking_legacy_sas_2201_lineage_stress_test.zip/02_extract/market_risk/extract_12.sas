/* Synthetic bank fixture | business area: market_risk | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.market_risk_06 out=work.extract_sort_market_risk_12 nodupkey;
 by customer_id account_id;
run;
data ext.market_risk_extract_12;
 set work.extract_sort_market_risk_12;
 if risk_score >= 0;
run;
