/* Synthetic bank fixture | business area: market_risk | layer: extract | script: 0006 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sql;
create table ext.market_risk_extract_06 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from src.market_risk_03 as a
where a.balance_amt is not null;
quit;
