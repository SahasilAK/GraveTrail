/* Synthetic bank fixture | business area: credit_cards | layer: extract | script: 0005 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_credit_cards_05;
 set src.credit_cards_03(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.credit_cards_extract_05;
 set work.x_credit_cards_05;
 balance_amt = round(balance_amt,0.01);
run;
