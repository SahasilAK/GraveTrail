/* Synthetic bank fixture | business area: credit_cards | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.credit_cards_02 out=work.extract_sort_credit_cards_04 nodupkey;
 by customer_id account_id;
run;
data ext.credit_cards_extract_04;
 set work.extract_sort_credit_cards_04;
 if risk_score >= 0;
run;
