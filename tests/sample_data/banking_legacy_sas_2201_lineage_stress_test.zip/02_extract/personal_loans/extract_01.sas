/* Synthetic bank fixture | business area: personal_loans | layer: extract | script: 0001 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_personal_loans_01;
 set src.personal_loans_01(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.personal_loans_extract_01;
 set work.x_personal_loans_01;
 balance_amt = round(balance_amt,0.01);
run;
