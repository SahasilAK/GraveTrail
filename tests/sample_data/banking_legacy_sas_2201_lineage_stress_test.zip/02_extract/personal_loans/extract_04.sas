/* Synthetic bank fixture | business area: personal_loans | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.personal_loans_02 out=work.extract_sort_personal_loans_04 nodupkey;
 by customer_id account_id;
run;
data ext.personal_loans_extract_04;
 set work.extract_sort_personal_loans_04;
 if risk_score >= 0;
run;
