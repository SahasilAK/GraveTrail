/* Synthetic bank fixture | business area: personal_loans | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.personal_loans_06 out=work.extract_sort_personal_loans_12 nodupkey;
 by customer_id account_id;
run;
data ext.personal_loans_extract_12;
 set work.extract_sort_personal_loans_12;
 if risk_score >= 0;
run;
