/* Synthetic bank fixture | business area: personal_loans | layer: extract | script: 0010 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sql;
create table ext.personal_loans_extract_10 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from src.personal_loans_05 as a
where a.balance_amt is not null;
quit;
