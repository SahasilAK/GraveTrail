/* Synthetic bank fixture | business area: commercial_lending | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.commercial_lending_02 out=work.extract_sort_commercial_lending_04 nodupkey;
 by customer_id account_id;
run;
data ext.commercial_lending_extract_04;
 set work.extract_sort_commercial_lending_04;
 if risk_score >= 0;
run;
