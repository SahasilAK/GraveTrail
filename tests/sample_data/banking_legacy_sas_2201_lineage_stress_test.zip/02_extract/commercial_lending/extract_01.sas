/* Synthetic bank fixture | business area: commercial_lending | layer: extract | script: 0001 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_commercial_lending_01;
 set src.commercial_lending_01(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.commercial_lending_extract_01;
 set work.x_commercial_lending_01;
 balance_amt = round(balance_amt,0.01);
run;
