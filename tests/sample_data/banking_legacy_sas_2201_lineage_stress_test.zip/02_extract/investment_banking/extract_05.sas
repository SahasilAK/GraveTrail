/* Synthetic bank fixture | business area: investment_banking | layer: extract | script: 0005 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_investment_banking_05;
 set src.investment_banking_03(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.investment_banking_extract_05;
 set work.x_investment_banking_05;
 balance_amt = round(balance_amt,0.01);
run;
