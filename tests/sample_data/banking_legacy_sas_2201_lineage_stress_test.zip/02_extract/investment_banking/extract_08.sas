/* Synthetic bank fixture | business area: investment_banking | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.investment_banking_04 out=work.extract_sort_investment_banking_08 nodupkey;
 by customer_id account_id;
run;
data ext.investment_banking_extract_08;
 set work.extract_sort_investment_banking_08;
 if risk_score >= 0;
run;
