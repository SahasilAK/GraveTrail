/* Synthetic bank fixture | business area: liquidity | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.liquidity_02 out=work.extract_sort_liquidity_04 nodupkey;
 by customer_id account_id;
run;
data ext.liquidity_extract_04;
 set work.extract_sort_liquidity_04;
 if risk_score >= 0;
run;
