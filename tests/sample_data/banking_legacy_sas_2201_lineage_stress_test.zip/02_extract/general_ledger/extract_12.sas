/* Synthetic bank fixture | business area: general_ledger | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.general_ledger_06 out=work.extract_sort_general_ledger_12 nodupkey;
 by customer_id account_id;
run;
data ext.general_ledger_extract_12;
 set work.extract_sort_general_ledger_12;
 if risk_score >= 0;
run;
