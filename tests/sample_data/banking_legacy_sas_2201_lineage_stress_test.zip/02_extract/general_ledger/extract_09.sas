/* Synthetic bank fixture | business area: general_ledger | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_general_ledger_09;
 set src.general_ledger_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.general_ledger_extract_09;
 set work.x_general_ledger_09;
 balance_amt = round(balance_amt,0.01);
run;
