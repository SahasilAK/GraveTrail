/* Synthetic bank fixture | business area: general_ledger | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.general_ledger_02 out=work.extract_sort_general_ledger_04 nodupkey;
 by customer_id account_id;
run;
data ext.general_ledger_extract_04;
 set work.extract_sort_general_ledger_04;
 if risk_score >= 0;
run;
