/* Synthetic bank fixture | business area: foreign_exchange | layer: extract | script: 0004 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.foreign_exchange_02 out=work.extract_sort_foreign_exchange_04 nodupkey;
 by customer_id account_id;
run;
data ext.foreign_exchange_extract_04;
 set work.extract_sort_foreign_exchange_04;
 if risk_score >= 0;
run;
