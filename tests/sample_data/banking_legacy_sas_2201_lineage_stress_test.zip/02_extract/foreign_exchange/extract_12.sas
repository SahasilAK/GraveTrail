/* Synthetic bank fixture | business area: foreign_exchange | layer: extract | script: 0012 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.foreign_exchange_06 out=work.extract_sort_foreign_exchange_12 nodupkey;
 by customer_id account_id;
run;
data ext.foreign_exchange_extract_12;
 set work.extract_sort_foreign_exchange_12;
 if risk_score >= 0;
run;
