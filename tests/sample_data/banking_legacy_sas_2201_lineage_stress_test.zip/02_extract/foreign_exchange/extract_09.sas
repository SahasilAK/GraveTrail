/* Synthetic bank fixture | business area: foreign_exchange | layer: extract | script: 0009 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data work.x_foreign_exchange_09;
 set src.foreign_exchange_05(where=(status_cd='A'));
 length extract_channel $8; extract_channel='BATCH';
run;
data ext.foreign_exchange_extract_09;
 set work.x_foreign_exchange_09;
 balance_amt = round(balance_amt,0.01);
run;
