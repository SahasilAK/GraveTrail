/* Synthetic bank fixture | business area: trading | layer: extract | script: 0011 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
data ext.trading_extract_11;
 set src.trading_06(keep=customer_id account_id as_of_date balance_amt transaction_amt risk_score status_cd);
 if as_of_date >= '01JAN2025'd;
 retain batch_id 1;
run;
