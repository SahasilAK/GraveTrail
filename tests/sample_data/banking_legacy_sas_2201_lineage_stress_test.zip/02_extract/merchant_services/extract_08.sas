/* Synthetic bank fixture | business area: merchant_services | layer: extract | script: 0008 */
/* Filter, reformat and extract source datasets; no external systems are contacted by this script. */
proc sort data=src.merchant_services_04 out=work.extract_sort_merchant_services_08 nodupkey;
 by customer_id account_id;
run;
data ext.merchant_services_extract_08;
 set work.extract_sort_merchant_services_08;
 if risk_score >= 0;
run;
