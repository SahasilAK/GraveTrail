/* Synthetic bank fixture | business area: credit_cards | layer: staging | script: 0011 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sort data=ext.credit_cards_extract_11 out=work.srt_a_credit_cards_10; by customer_id account_id; run;
proc sort data=ext.credit_cards_extract_04 out=work.srt_b_credit_cards_10; by customer_id account_id; run;
data stg.credit_cards_stage_11;
 merge work.srt_a_credit_cards_10(in=in_a) work.srt_b_credit_cards_10(in=in_b rename=(balance_amt=balance_amt_b transaction_amt=transaction_amt_b));
 by customer_id account_id;
 if in_a;
 balance_amt=sum(balance_amt,balance_amt_b);
 transaction_amt=sum(transaction_amt,transaction_amt_b);
 drop balance_amt_b transaction_amt_b;
run;
