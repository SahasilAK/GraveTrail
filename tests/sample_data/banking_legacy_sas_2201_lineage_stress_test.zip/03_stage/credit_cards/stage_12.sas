/* Synthetic bank fixture | business area: credit_cards | layer: staging | script: 0012 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
data work.stage_union_credit_cards_11;
 set ext.credit_cards_extract_12(in=in_a) ext.credit_cards_extract_05(in=in_b);
 if in_a or in_b;
run;
proc sql;
create table stg.credit_cards_stage_12 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from work.stage_union_credit_cards_11 as a
where a.account_id is not null;
quit;
