/* Synthetic bank fixture | business area: aml | layer: staging | script: 0010 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sql;
create table stg.aml_stage_10 as
select a.customer_id, a.account_id, a.as_of_date,
       case when a.status_cd = 'A' then a.balance_amt else 0 end as balance_amt,
       abs(a.transaction_amt) as transaction_amt,
       a.risk_score, a.status_cd
from ext.aml_extract_10 as a
left join ext.aml_extract_03 as b
  on a.customer_id = b.customer_id and a.account_id = b.account_id;
quit;
