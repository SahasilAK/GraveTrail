/* Synthetic bank fixture | business area: aml | layer: staging | script: 0008 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sort data=ext.aml_extract_08 out=work.srt_a_aml_07; by customer_id account_id; run;
proc sort data=ext.aml_extract_01 out=work.srt_b_aml_07; by customer_id account_id; run;
data stg.aml_stage_08;
 merge work.srt_a_aml_07(in=in_a) work.srt_b_aml_07(in=in_b rename=(balance_amt=balance_amt_b transaction_amt=transaction_amt_b));
 by customer_id account_id;
 if in_a;
 balance_amt=sum(balance_amt,balance_amt_b);
 transaction_amt=sum(transaction_amt,transaction_amt_b);
 drop balance_amt_b transaction_amt_b;
run;
