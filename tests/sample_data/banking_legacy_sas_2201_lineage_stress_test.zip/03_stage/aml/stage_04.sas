/* Synthetic bank fixture | business area: aml | layer: staging | script: 0004 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sql;
create table stg.aml_stage_04 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt as balance_amt,
       a.transaction_amt as transaction_amt,
       a.risk_score, a.status_cd
from ext.aml_extract_04 as a
left join ext.aml_extract_09 as b
  on a.customer_id = b.customer_id and a.account_id = b.account_id;
quit;
