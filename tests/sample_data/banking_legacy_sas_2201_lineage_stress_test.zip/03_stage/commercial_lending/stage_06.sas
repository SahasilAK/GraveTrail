/* Synthetic bank fixture | business area: commercial_lending | layer: staging | script: 0006 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
data work.stage_union_commercial_lending_05;
 set ext.commercial_lending_extract_06(in=in_a) ext.commercial_lending_extract_11(in=in_b);
 if in_a or in_b;
run;
proc sql;
create table stg.commercial_lending_stage_06 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from work.stage_union_commercial_lending_05 as a
where a.account_id is not null;
quit;
