/* Synthetic bank fixture | business area: commercial_lending | layer: staging | script: 0009 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
data work.stage_union_commercial_lending_08;
 set ext.commercial_lending_extract_09(in=in_a) ext.commercial_lending_extract_02(in=in_b);
 if in_a or in_b;
run;
proc sql;
create table stg.commercial_lending_stage_09 as
select a.customer_id, a.account_id, a.as_of_date,
       a.balance_amt, a.transaction_amt, a.risk_score, a.status_cd
from work.stage_union_commercial_lending_08 as a
where a.account_id is not null;
quit;
