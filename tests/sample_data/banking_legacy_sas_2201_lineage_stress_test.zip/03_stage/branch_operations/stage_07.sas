/* Synthetic bank fixture | business area: branch_operations | layer: staging | script: 0007 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sql;
create table stg.branch_operations_stage_07 as
select a.customer_id, a.account_id, a.as_of_date,
       round(a.balance_amt * (1+coalesce(a.risk_score,0)/10000),2) as balance_amt,
       a.transaction_amt as transaction_amt,
       a.risk_score, a.status_cd
from ext.branch_operations_extract_07 as a
left join ext.branch_operations_extract_12 as b
  on a.customer_id = b.customer_id and a.account_id = b.account_id;
quit;
