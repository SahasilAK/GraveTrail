/* Synthetic bank fixture | business area: branch_operations | layer: staging | script: 0002 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sort data=ext.branch_operations_extract_02 out=work.srt_a_branch_operations_01; by customer_id account_id; run;
proc sort data=ext.branch_operations_extract_07 out=work.srt_b_branch_operations_01; by customer_id account_id; run;
data stg.branch_operations_stage_02;
 merge work.srt_a_branch_operations_01(in=in_a) work.srt_b_branch_operations_01(in=in_b rename=(balance_amt=balance_amt_b transaction_amt=transaction_amt_b));
 by customer_id account_id;
 if in_a;
 balance_amt=sum(balance_amt,balance_amt_b);
 transaction_amt=sum(transaction_amt,transaction_amt_b);
 drop balance_amt_b transaction_amt_b;
run;
