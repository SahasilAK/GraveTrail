/* Synthetic bank fixture | business area: branch_operations | layer: staging | script: 0001 */
/* Multi-source cleansing and identity normalization; no external systems are contacted by this script. */
proc sql;
create table stg.branch_operations_stage_01 as
select a.customer_id, a.account_id, a.as_of_date,
       coalesce(a.balance_amt,0) + 0.05*coalesce(b.balance_amt,0) as balance_amt,
       coalesce(a.transaction_amt,0) + 0.10*coalesce(b.transaction_amt,0) as transaction_amt,
       a.risk_score, a.status_cd
from ext.branch_operations_extract_01 as a
left join ext.branch_operations_extract_06 as b
  on a.customer_id = b.customer_id and a.account_id = b.account_id;
quit;
