/* Configure once per SAS session. Requires an accessible, writable BANK_ROOT. */
/* Optional: set BANK_ROOT before %include to choose a persistent path. */
%macro banking_fixture_initialize();
  %global BANK_ROOT;
  %if not %symexist(BANK_ROOT) %then %let BANK_ROOT=%sysfunc(pathname(WORK));
  options dlcreatedir;
  libname src "&BANK_ROOT./bank_src";
  libname ext "&BANK_ROOT./bank_ext";
  libname stg "&BANK_ROOT./bank_stg";
  libname core "&BANK_ROOT./bank_core";
  libname mart "&BANK_ROOT./bank_mart";
  libname rpt "&BANK_ROOT./bank_rpt";
  libname reg "&BANK_ROOT./bank_reg";
  libname pub "&BANK_ROOT./bank_pub";
  libname qa "&BANK_ROOT./bank_qa";
  options nodlcreatedir;
%mend banking_fixture_initialize;
%banking_fixture_initialize();
