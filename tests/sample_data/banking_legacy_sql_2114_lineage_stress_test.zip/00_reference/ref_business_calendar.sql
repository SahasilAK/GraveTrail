-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.business_calendar

CREATE OR REPLACE TABLE ref.business_calendar AS
SELECT 'A' AS code, 'business_calendar_A' AS description, 50 AS sort_order
UNION ALL
SELECT 'B' AS code, 'business_calendar_B' AS description, 51 AS sort_order
UNION ALL
SELECT 'C' AS code, 'business_calendar_C' AS description, 52 AS sort_order
UNION ALL
SELECT 'D' AS code, 'business_calendar_D' AS description, 53 AS sort_order;
