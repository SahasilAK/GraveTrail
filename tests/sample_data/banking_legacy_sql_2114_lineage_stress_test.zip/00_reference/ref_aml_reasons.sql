-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.aml_reasons

CREATE OR REPLACE TABLE ref.aml_reasons AS
SELECT 'A' AS code, 'aml_reasons_A' AS description, 110 AS sort_order
UNION ALL
SELECT 'B' AS code, 'aml_reasons_B' AS description, 111 AS sort_order
UNION ALL
SELECT 'C' AS code, 'aml_reasons_C' AS description, 112 AS sort_order
UNION ALL
SELECT 'D' AS code, 'aml_reasons_D' AS description, 113 AS sort_order;
