-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.branch_regions

CREATE OR REPLACE TABLE ref.branch_regions AS
SELECT 'A' AS code, 'branch_regions_A' AS description, 20 AS sort_order
UNION ALL
SELECT 'B' AS code, 'branch_regions_B' AS description, 21 AS sort_order
UNION ALL
SELECT 'C' AS code, 'branch_regions_C' AS description, 22 AS sort_order
UNION ALL
SELECT 'D' AS code, 'branch_regions_D' AS description, 23 AS sort_order;
