-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.event_codes

CREATE OR REPLACE TABLE ref.event_codes AS
SELECT 'A' AS code, 'event_codes_A' AS description, 120 AS sort_order
UNION ALL
SELECT 'B' AS code, 'event_codes_B' AS description, 121 AS sort_order
UNION ALL
SELECT 'C' AS code, 'event_codes_C' AS description, 122 AS sort_order
UNION ALL
SELECT 'D' AS code, 'event_codes_D' AS description, 123 AS sort_order;
