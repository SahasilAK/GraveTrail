-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.gl_mappings

CREATE OR REPLACE TABLE ref.gl_mappings AS
SELECT 'A' AS code, 'gl_mappings_A' AS description, 60 AS sort_order
UNION ALL
SELECT 'B' AS code, 'gl_mappings_B' AS description, 61 AS sort_order
UNION ALL
SELECT 'C' AS code, 'gl_mappings_C' AS description, 62 AS sort_order
UNION ALL
SELECT 'D' AS code, 'gl_mappings_D' AS description, 63 AS sort_order;
