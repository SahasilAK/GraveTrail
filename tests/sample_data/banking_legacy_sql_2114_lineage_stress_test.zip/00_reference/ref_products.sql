-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.products

CREATE OR REPLACE TABLE ref.products AS
SELECT 'A' AS code, 'products_A' AS description, 90 AS sort_order
UNION ALL
SELECT 'B' AS code, 'products_B' AS description, 91 AS sort_order
UNION ALL
SELECT 'C' AS code, 'products_C' AS description, 92 AS sort_order
UNION ALL
SELECT 'D' AS code, 'products_D' AS description, 93 AS sort_order;
