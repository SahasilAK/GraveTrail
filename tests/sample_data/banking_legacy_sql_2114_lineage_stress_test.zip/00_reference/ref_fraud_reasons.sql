-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.fraud_reasons

CREATE OR REPLACE TABLE ref.fraud_reasons AS
SELECT 'A' AS code, 'fraud_reasons_A' AS description, 100 AS sort_order
UNION ALL
SELECT 'B' AS code, 'fraud_reasons_B' AS description, 101 AS sort_order
UNION ALL
SELECT 'C' AS code, 'fraud_reasons_C' AS description, 102 AS sort_order
UNION ALL
SELECT 'D' AS code, 'fraud_reasons_D' AS description, 103 AS sort_order;
