-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.exchange_rates

CREATE OR REPLACE TABLE ref.exchange_rates AS
SELECT 'A' AS code, 'exchange_rates_A' AS description, 130 AS sort_order
UNION ALL
SELECT 'B' AS code, 'exchange_rates_B' AS description, 131 AS sort_order
UNION ALL
SELECT 'C' AS code, 'exchange_rates_C' AS description, 132 AS sort_order
UNION ALL
SELECT 'D' AS code, 'exchange_rates_D' AS description, 133 AS sort_order;
