-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.country_codes

CREATE OR REPLACE TABLE ref.country_codes AS
SELECT 'A' AS code, 'country_codes_A' AS description, 10 AS sort_order
UNION ALL
SELECT 'B' AS code, 'country_codes_B' AS description, 11 AS sort_order
UNION ALL
SELECT 'C' AS code, 'country_codes_C' AS description, 12 AS sort_order
UNION ALL
SELECT 'D' AS code, 'country_codes_D' AS description, 13 AS sort_order;
