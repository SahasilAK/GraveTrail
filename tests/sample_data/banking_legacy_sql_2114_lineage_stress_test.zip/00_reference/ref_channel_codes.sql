-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.channel_codes

CREATE OR REPLACE TABLE ref.channel_codes AS
SELECT 'A' AS code, 'channel_codes_A' AS description, 30 AS sort_order
UNION ALL
SELECT 'B' AS code, 'channel_codes_B' AS description, 31 AS sort_order
UNION ALL
SELECT 'C' AS code, 'channel_codes_C' AS description, 32 AS sort_order
UNION ALL
SELECT 'D' AS code, 'channel_codes_D' AS description, 33 AS sort_order;
