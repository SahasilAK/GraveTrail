-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.risk_bands

CREATE OR REPLACE TABLE ref.risk_bands AS
SELECT 'A' AS code, 'risk_bands_A' AS description, 40 AS sort_order
UNION ALL
SELECT 'B' AS code, 'risk_bands_B' AS description, 41 AS sort_order
UNION ALL
SELECT 'C' AS code, 'risk_bands_C' AS description, 42 AS sort_order
UNION ALL
SELECT 'D' AS code, 'risk_bands_D' AS description, 43 AS sort_order;
