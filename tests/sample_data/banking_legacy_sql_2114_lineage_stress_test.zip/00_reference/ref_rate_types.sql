-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.rate_types

CREATE OR REPLACE TABLE ref.rate_types AS
SELECT 'A' AS code, 'rate_types_A' AS description, 70 AS sort_order
UNION ALL
SELECT 'B' AS code, 'rate_types_B' AS description, 71 AS sort_order
UNION ALL
SELECT 'C' AS code, 'rate_types_C' AS description, 72 AS sort_order
UNION ALL
SELECT 'D' AS code, 'rate_types_D' AS description, 73 AS sort_order;
