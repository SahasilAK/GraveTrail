-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.currency_codes

CREATE OR REPLACE TABLE ref.currency_codes AS
SELECT 'USD' AS code, 'currency_codes_USD' AS description, 0 AS sort_order
UNION ALL
SELECT 'EUR' AS code, 'currency_codes_EUR' AS description, 1 AS sort_order
UNION ALL
SELECT 'GBP' AS code, 'currency_codes_GBP' AS description, 2 AS sort_order
UNION ALL
SELECT 'INR' AS code, 'currency_codes_INR' AS description, 3 AS sort_order;
