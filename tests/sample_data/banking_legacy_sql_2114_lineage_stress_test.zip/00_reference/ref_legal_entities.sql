-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=reference | domain=shared | dialect=ansi | scenario=static_reference_lookup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: ref.legal_entities

CREATE OR REPLACE TABLE ref.legal_entities AS
SELECT 'A' AS code, 'legal_entities_A' AS description, 80 AS sort_order
UNION ALL
SELECT 'B' AS code, 'legal_entities_B' AS description, 81 AS sort_order
UNION ALL
SELECT 'C' AS code, 'legal_entities_C' AS description, 82 AS sort_order
UNION ALL
SELECT 'D' AS code, 'legal_entities_D' AS description, 83 AS sort_order;
