-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=fx | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_fx.fx_forwards
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_fx.fx_forwards AS
SELECT 6301 AS record_id, 64 AS customer_id, 14 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1207.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 63 AS risk_score, 'FX_FX_FORWARDS_6301' AS reference_code
UNION ALL
SELECT 6302 AS record_id, 65 AS customer_id, 15 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1244.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 70 AS risk_score, 'FX_FX_FORWARDS_6302' AS reference_code
UNION ALL
SELECT 6303 AS record_id, 66 AS customer_id, 16 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1281.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 77 AS risk_score, 'FX_FX_FORWARDS_6303' AS reference_code
UNION ALL
SELECT 6304 AS record_id, 67 AS customer_id, 17 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1318.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 84 AS risk_score, 'FX_FX_FORWARDS_6304' AS reference_code;
