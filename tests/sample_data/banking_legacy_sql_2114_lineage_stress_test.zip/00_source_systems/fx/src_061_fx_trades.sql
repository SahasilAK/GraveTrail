-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=fx | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_fx.fx_trades
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_fx.fx_trades AS
SELECT 6101 AS record_id, 62 AS customer_id, 12 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1169.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 61 AS risk_score, 'FX_FX_TRADES_6101' AS reference_code
UNION ALL
SELECT 6102 AS record_id, 63 AS customer_id, 13 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1206.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 68 AS risk_score, 'FX_FX_TRADES_6102' AS reference_code
UNION ALL
SELECT 6103 AS record_id, 64 AS customer_id, 14 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1243.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 75 AS risk_score, 'FX_FX_TRADES_6103' AS reference_code
UNION ALL
SELECT 6104 AS record_id, 65 AS customer_id, 15 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1280.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 82 AS risk_score, 'FX_FX_TRADES_6104' AS reference_code;
