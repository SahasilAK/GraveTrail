-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=fx | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_fx.fx_exposures
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_fx.fx_exposures AS
SELECT 6601 AS record_id, 67 AS customer_id, 17 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1264.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 66 AS risk_score, 'FX_FX_EXPOSURES_6601' AS reference_code
UNION ALL
SELECT 6602 AS record_id, 68 AS customer_id, 18 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1301.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 73 AS risk_score, 'FX_FX_EXPOSURES_6602' AS reference_code
UNION ALL
SELECT 6603 AS record_id, 69 AS customer_id, 19 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1338.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 80 AS risk_score, 'FX_FX_EXPOSURES_6603' AS reference_code
UNION ALL
SELECT 6604 AS record_id, 70 AS customer_id, 20 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1375.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 87 AS risk_score, 'FX_FX_EXPOSURES_6604' AS reference_code;
