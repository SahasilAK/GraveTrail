-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=payments | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_payments.payment_orders
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_payments.payment_orders AS
SELECT 3701 AS record_id, 38 AS customer_id, 38 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 713.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 37 AS risk_score, 'PAYMENTS_PAYMENT_ORDERS_3701' AS reference_code
UNION ALL
SELECT 3702 AS record_id, 39 AS customer_id, 39 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 750.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 44 AS risk_score, 'PAYMENTS_PAYMENT_ORDERS_3702' AS reference_code
UNION ALL
SELECT 3703 AS record_id, 40 AS customer_id, 40 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 787.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 51 AS risk_score, 'PAYMENTS_PAYMENT_ORDERS_3703' AS reference_code
UNION ALL
SELECT 3704 AS record_id, 41 AS customer_id, 41 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 824.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 58 AS risk_score, 'PAYMENTS_PAYMENT_ORDERS_3704' AS reference_code;
