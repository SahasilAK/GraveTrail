-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=digital | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_digital.customer_devices
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_digital.customer_devices AS
SELECT 13101 AS record_id, 42 AS customer_id, 32 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2499.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 32 AS risk_score, 'DIGITAL_CUSTOMER_DEVICES_13101' AS reference_code
UNION ALL
SELECT 13102 AS record_id, 43 AS customer_id, 33 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2536.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 39 AS risk_score, 'DIGITAL_CUSTOMER_DEVICES_13102' AS reference_code
UNION ALL
SELECT 13103 AS record_id, 44 AS customer_id, 34 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2573.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 46 AS risk_score, 'DIGITAL_CUSTOMER_DEVICES_13103' AS reference_code
UNION ALL
SELECT 13104 AS record_id, 45 AS customer_id, 35 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2610.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 53 AS risk_score, 'DIGITAL_CUSTOMER_DEVICES_13104' AS reference_code;
