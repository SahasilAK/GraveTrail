-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=digital | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_digital.api_requests
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_digital.api_requests AS
SELECT 13001 AS record_id, 41 AS customer_id, 31 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2480.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 31 AS risk_score, 'DIGITAL_API_REQUESTS_13001' AS reference_code
UNION ALL
SELECT 13002 AS record_id, 42 AS customer_id, 32 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2517.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 38 AS risk_score, 'DIGITAL_API_REQUESTS_13002' AS reference_code
UNION ALL
SELECT 13003 AS record_id, 43 AS customer_id, 33 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2554.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 45 AS risk_score, 'DIGITAL_API_REQUESTS_13003' AS reference_code
UNION ALL
SELECT 13004 AS record_id, 44 AS customer_id, 34 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2591.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 52 AS risk_score, 'DIGITAL_API_REQUESTS_13004' AS reference_code;
