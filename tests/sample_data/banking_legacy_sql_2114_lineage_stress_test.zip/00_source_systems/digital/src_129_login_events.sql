-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=digital | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_digital.login_events
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_digital.login_events AS
SELECT 12901 AS record_id, 40 AS customer_id, 30 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2461.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 30 AS risk_score, 'DIGITAL_LOGIN_EVENTS_12901' AS reference_code
UNION ALL
SELECT 12902 AS record_id, 41 AS customer_id, 31 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2498.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 37 AS risk_score, 'DIGITAL_LOGIN_EVENTS_12902' AS reference_code
UNION ALL
SELECT 12903 AS record_id, 42 AS customer_id, 32 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2535.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 44 AS risk_score, 'DIGITAL_LOGIN_EVENTS_12903' AS reference_code
UNION ALL
SELECT 12904 AS record_id, 43 AS customer_id, 33 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2572.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 51 AS risk_score, 'DIGITAL_LOGIN_EVENTS_12904' AS reference_code;
