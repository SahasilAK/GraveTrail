-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=digital | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_digital.mobile_sessions
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_digital.mobile_sessions AS
SELECT 12701 AS record_id, 38 AS customer_id, 28 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2423.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 28 AS risk_score, 'DIGITAL_MOBILE_SESSIONS_12701' AS reference_code
UNION ALL
SELECT 12702 AS record_id, 39 AS customer_id, 29 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2460.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 35 AS risk_score, 'DIGITAL_MOBILE_SESSIONS_12702' AS reference_code
UNION ALL
SELECT 12703 AS record_id, 40 AS customer_id, 30 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2497.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 42 AS risk_score, 'DIGITAL_MOBILE_SESSIONS_12703' AS reference_code
UNION ALL
SELECT 12704 AS record_id, 41 AS customer_id, 31 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2534.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 49 AS risk_score, 'DIGITAL_MOBILE_SESSIONS_12704' AS reference_code;
