-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=ach | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_ach.ach_returns
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_ach.ach_returns AS
SELECT 5101 AS record_id, 52 AS customer_id, 2 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 979.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 51 AS risk_score, 'ACH_ACH_RETURNS_5101' AS reference_code
UNION ALL
SELECT 5102 AS record_id, 53 AS customer_id, 3 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1016.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 58 AS risk_score, 'ACH_ACH_RETURNS_5102' AS reference_code
UNION ALL
SELECT 5103 AS record_id, 54 AS customer_id, 4 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1053.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 65 AS risk_score, 'ACH_ACH_RETURNS_5103' AS reference_code
UNION ALL
SELECT 5104 AS record_id, 55 AS customer_id, 5 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1090.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 72 AS risk_score, 'ACH_ACH_RETURNS_5104' AS reference_code;
