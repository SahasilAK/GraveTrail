-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=ach | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_ach.ach_batches
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_ach.ach_batches AS
SELECT 4901 AS record_id, 50 AS customer_id, 50 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 941.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 49 AS risk_score, 'ACH_ACH_BATCHES_4901' AS reference_code
UNION ALL
SELECT 4902 AS record_id, 51 AS customer_id, 1 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 978.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 56 AS risk_score, 'ACH_ACH_BATCHES_4902' AS reference_code
UNION ALL
SELECT 4903 AS record_id, 52 AS customer_id, 2 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1015.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 63 AS risk_score, 'ACH_ACH_BATCHES_4903' AS reference_code
UNION ALL
SELECT 4904 AS record_id, 53 AS customer_id, 3 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1052.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 70 AS risk_score, 'ACH_ACH_BATCHES_4904' AS reference_code;
