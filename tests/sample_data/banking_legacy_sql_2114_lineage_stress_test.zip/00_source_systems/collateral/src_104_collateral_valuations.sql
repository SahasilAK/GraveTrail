-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=collateral | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_collateral.collateral_valuations
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_collateral.collateral_valuations AS
SELECT 10401 AS record_id, 15 AS customer_id, 5 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1986.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 5 AS risk_score, 'COLLATERAL_COLLATERAL_VALUATIONS_10401' AS reference_code
UNION ALL
SELECT 10402 AS record_id, 16 AS customer_id, 6 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2023.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 12 AS risk_score, 'COLLATERAL_COLLATERAL_VALUATIONS_10402' AS reference_code
UNION ALL
SELECT 10403 AS record_id, 17 AS customer_id, 7 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2060.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 19 AS risk_score, 'COLLATERAL_COLLATERAL_VALUATIONS_10403' AS reference_code
UNION ALL
SELECT 10404 AS record_id, 18 AS customer_id, 8 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2097.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 26 AS risk_score, 'COLLATERAL_COLLATERAL_VALUATIONS_10404' AS reference_code;
