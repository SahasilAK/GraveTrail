-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=treasury | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_treasury.treasury_cashflows
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_treasury.treasury_cashflows AS
SELECT 5901 AS record_id, 60 AS customer_id, 10 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1131.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 59 AS risk_score, 'TREASURY_TREASURY_CASHFLOWS_5901' AS reference_code
UNION ALL
SELECT 5902 AS record_id, 61 AS customer_id, 11 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1168.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 66 AS risk_score, 'TREASURY_TREASURY_CASHFLOWS_5902' AS reference_code
UNION ALL
SELECT 5903 AS record_id, 62 AS customer_id, 12 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1205.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 73 AS risk_score, 'TREASURY_TREASURY_CASHFLOWS_5903' AS reference_code
UNION ALL
SELECT 5904 AS record_id, 63 AS customer_id, 13 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1242.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 80 AS risk_score, 'TREASURY_TREASURY_CASHFLOWS_5904' AS reference_code;
