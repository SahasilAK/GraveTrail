-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=treasury | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_treasury.treasury_rates
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_treasury.treasury_rates AS
SELECT 6001 AS record_id, 61 AS customer_id, 11 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1150.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 60 AS risk_score, 'TREASURY_TREASURY_RATES_6001' AS reference_code
UNION ALL
SELECT 6002 AS record_id, 62 AS customer_id, 12 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1187.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 67 AS risk_score, 'TREASURY_TREASURY_RATES_6002' AS reference_code
UNION ALL
SELECT 6003 AS record_id, 63 AS customer_id, 13 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1224.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 74 AS risk_score, 'TREASURY_TREASURY_RATES_6003' AS reference_code
UNION ALL
SELECT 6004 AS record_id, 64 AS customer_id, 14 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1261.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 81 AS risk_score, 'TREASURY_TREASURY_RATES_6004' AS reference_code;
