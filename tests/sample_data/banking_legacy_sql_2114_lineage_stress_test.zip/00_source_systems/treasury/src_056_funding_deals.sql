-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=treasury | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_treasury.funding_deals
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_treasury.funding_deals AS
SELECT 5601 AS record_id, 57 AS customer_id, 7 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1074.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 56 AS risk_score, 'TREASURY_FUNDING_DEALS_5601' AS reference_code
UNION ALL
SELECT 5602 AS record_id, 58 AS customer_id, 8 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1111.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 63 AS risk_score, 'TREASURY_FUNDING_DEALS_5602' AS reference_code
UNION ALL
SELECT 5603 AS record_id, 59 AS customer_id, 9 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1148.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 70 AS risk_score, 'TREASURY_FUNDING_DEALS_5603' AS reference_code
UNION ALL
SELECT 5604 AS record_id, 60 AS customer_id, 10 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1185.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 77 AS risk_score, 'TREASURY_FUNDING_DEALS_5604' AS reference_code;
