-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=treasury | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_treasury.treasury_positions
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_treasury.treasury_positions AS
SELECT 5501 AS record_id, 56 AS customer_id, 6 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1055.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 55 AS risk_score, 'TREASURY_TREASURY_POSITIONS_5501' AS reference_code
UNION ALL
SELECT 5502 AS record_id, 57 AS customer_id, 7 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1092.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 62 AS risk_score, 'TREASURY_TREASURY_POSITIONS_5502' AS reference_code
UNION ALL
SELECT 5503 AS record_id, 58 AS customer_id, 8 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1129.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 69 AS risk_score, 'TREASURY_TREASURY_POSITIONS_5503' AS reference_code
UNION ALL
SELECT 5504 AS record_id, 59 AS customer_id, 9 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1166.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 76 AS risk_score, 'TREASURY_TREASURY_POSITIONS_5504' AS reference_code;
