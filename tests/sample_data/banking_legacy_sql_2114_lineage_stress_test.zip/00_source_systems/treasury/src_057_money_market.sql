-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=treasury | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_treasury.money_market
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_treasury.money_market AS
SELECT 5701 AS record_id, 58 AS customer_id, 8 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1093.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 57 AS risk_score, 'TREASURY_MONEY_MARKET_5701' AS reference_code
UNION ALL
SELECT 5702 AS record_id, 59 AS customer_id, 9 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1130.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 64 AS risk_score, 'TREASURY_MONEY_MARKET_5702' AS reference_code
UNION ALL
SELECT 5703 AS record_id, 60 AS customer_id, 10 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1167.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 71 AS risk_score, 'TREASURY_MONEY_MARKET_5703' AS reference_code
UNION ALL
SELECT 5704 AS record_id, 61 AS customer_id, 11 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1204.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 78 AS risk_score, 'TREASURY_MONEY_MARKET_5704' AS reference_code;
