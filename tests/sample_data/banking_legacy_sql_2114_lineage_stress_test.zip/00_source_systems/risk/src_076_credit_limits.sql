-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=risk | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_risk.credit_limits
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_risk.credit_limits AS
SELECT 7601 AS record_id, 77 AS customer_id, 27 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1454.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 76 AS risk_score, 'RISK_CREDIT_LIMITS_7601' AS reference_code
UNION ALL
SELECT 7602 AS record_id, 78 AS customer_id, 28 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1491.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 83 AS risk_score, 'RISK_CREDIT_LIMITS_7602' AS reference_code
UNION ALL
SELECT 7603 AS record_id, 79 AS customer_id, 29 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1528.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 90 AS risk_score, 'RISK_CREDIT_LIMITS_7603' AS reference_code
UNION ALL
SELECT 7604 AS record_id, 80 AS customer_id, 30 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1565.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 97 AS risk_score, 'RISK_CREDIT_LIMITS_7604' AS reference_code;
