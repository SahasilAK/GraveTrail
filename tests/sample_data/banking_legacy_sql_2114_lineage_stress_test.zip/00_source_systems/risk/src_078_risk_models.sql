-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=risk | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_risk.risk_models
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_risk.risk_models AS
SELECT 7801 AS record_id, 79 AS customer_id, 29 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1492.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 78 AS risk_score, 'RISK_RISK_MODELS_7801' AS reference_code
UNION ALL
SELECT 7802 AS record_id, 80 AS customer_id, 30 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1529.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 85 AS risk_score, 'RISK_RISK_MODELS_7802' AS reference_code
UNION ALL
SELECT 7803 AS record_id, 81 AS customer_id, 31 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1566.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 92 AS risk_score, 'RISK_RISK_MODELS_7803' AS reference_code
UNION ALL
SELECT 7804 AS record_id, 82 AS customer_id, 32 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1603.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 0 AS risk_score, 'RISK_RISK_MODELS_7804' AS reference_code;
