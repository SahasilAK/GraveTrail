-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=risk | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_risk.risk_events
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_risk.risk_events AS
SELECT 7701 AS record_id, 78 AS customer_id, 28 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1473.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 77 AS risk_score, 'RISK_RISK_EVENTS_7701' AS reference_code
UNION ALL
SELECT 7702 AS record_id, 79 AS customer_id, 29 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1510.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 84 AS risk_score, 'RISK_RISK_EVENTS_7702' AS reference_code
UNION ALL
SELECT 7703 AS record_id, 80 AS customer_id, 30 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1547.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 91 AS risk_score, 'RISK_RISK_EVENTS_7703' AS reference_code
UNION ALL
SELECT 7704 AS record_id, 81 AS customer_id, 31 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1584.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 98 AS risk_score, 'RISK_RISK_EVENTS_7704' AS reference_code;
