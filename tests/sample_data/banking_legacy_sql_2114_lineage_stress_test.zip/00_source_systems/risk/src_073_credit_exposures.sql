-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=risk | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_risk.credit_exposures
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_risk.credit_exposures AS
SELECT 7301 AS record_id, 74 AS customer_id, 24 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1397.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 73 AS risk_score, 'RISK_CREDIT_EXPOSURES_7301' AS reference_code
UNION ALL
SELECT 7302 AS record_id, 75 AS customer_id, 25 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1434.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 80 AS risk_score, 'RISK_CREDIT_EXPOSURES_7302' AS reference_code
UNION ALL
SELECT 7303 AS record_id, 76 AS customer_id, 26 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1471.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 87 AS risk_score, 'RISK_CREDIT_EXPOSURES_7303' AS reference_code
UNION ALL
SELECT 7304 AS record_id, 77 AS customer_id, 27 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1508.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 94 AS risk_score, 'RISK_CREDIT_EXPOSURES_7304' AS reference_code;
