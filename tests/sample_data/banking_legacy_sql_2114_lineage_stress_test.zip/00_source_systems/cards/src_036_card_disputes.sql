-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=cards | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_cards.card_disputes
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_cards.card_disputes AS
SELECT 3601 AS record_id, 37 AS customer_id, 37 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 694.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 36 AS risk_score, 'CARDS_CARD_DISPUTES_3601' AS reference_code
UNION ALL
SELECT 3602 AS record_id, 38 AS customer_id, 38 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 731.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 43 AS risk_score, 'CARDS_CARD_DISPUTES_3602' AS reference_code
UNION ALL
SELECT 3603 AS record_id, 39 AS customer_id, 39 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 768.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 50 AS risk_score, 'CARDS_CARD_DISPUTES_3603' AS reference_code
UNION ALL
SELECT 3604 AS record_id, 40 AS customer_id, 40 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 805.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 57 AS risk_score, 'CARDS_CARD_DISPUTES_3604' AS reference_code;
