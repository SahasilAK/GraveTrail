-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=cards | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_cards.card_limits
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_cards.card_limits AS
SELECT 3401 AS record_id, 35 AS customer_id, 35 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 656.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 34 AS risk_score, 'CARDS_CARD_LIMITS_3401' AS reference_code
UNION ALL
SELECT 3402 AS record_id, 36 AS customer_id, 36 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 693.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 41 AS risk_score, 'CARDS_CARD_LIMITS_3402' AS reference_code
UNION ALL
SELECT 3403 AS record_id, 37 AS customer_id, 37 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 730.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 48 AS risk_score, 'CARDS_CARD_LIMITS_3403' AS reference_code
UNION ALL
SELECT 3404 AS record_id, 38 AS customer_id, 38 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 767.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 55 AS risk_score, 'CARDS_CARD_LIMITS_3404' AS reference_code;
