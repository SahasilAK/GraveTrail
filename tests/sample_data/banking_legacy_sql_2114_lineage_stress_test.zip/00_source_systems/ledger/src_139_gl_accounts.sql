-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=ledger | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_ledger.gl_accounts
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_ledger.gl_accounts AS
SELECT 13901 AS record_id, 50 AS customer_id, 40 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2651.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 40 AS risk_score, 'LEDGER_GL_ACCOUNTS_13901' AS reference_code
UNION ALL
SELECT 13902 AS record_id, 51 AS customer_id, 41 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2688.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 47 AS risk_score, 'LEDGER_GL_ACCOUNTS_13902' AS reference_code
UNION ALL
SELECT 13903 AS record_id, 52 AS customer_id, 42 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2725.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 54 AS risk_score, 'LEDGER_GL_ACCOUNTS_13903' AS reference_code
UNION ALL
SELECT 13904 AS record_id, 53 AS customer_id, 43 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2762.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 61 AS risk_score, 'LEDGER_GL_ACCOUNTS_13904' AS reference_code;
