-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=ledger | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_ledger.journals
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_ledger.journals AS
SELECT 14101 AS record_id, 52 AS customer_id, 42 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2689.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 42 AS risk_score, 'LEDGER_JOURNALS_14101' AS reference_code
UNION ALL
SELECT 14102 AS record_id, 53 AS customer_id, 43 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2726.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 49 AS risk_score, 'LEDGER_JOURNALS_14102' AS reference_code
UNION ALL
SELECT 14103 AS record_id, 54 AS customer_id, 44 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2763.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 56 AS risk_score, 'LEDGER_JOURNALS_14103' AS reference_code
UNION ALL
SELECT 14104 AS record_id, 55 AS customer_id, 45 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2800.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 63 AS risk_score, 'LEDGER_JOURNALS_14104' AS reference_code;
