-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=ledger | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_ledger.journal_lines
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_ledger.journal_lines AS
SELECT 14201 AS record_id, 53 AS customer_id, 43 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2708.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 43 AS risk_score, 'LEDGER_JOURNAL_LINES_14201' AS reference_code
UNION ALL
SELECT 14202 AS record_id, 54 AS customer_id, 44 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2745.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 50 AS risk_score, 'LEDGER_JOURNAL_LINES_14202' AS reference_code
UNION ALL
SELECT 14203 AS record_id, 55 AS customer_id, 45 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2782.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 57 AS risk_score, 'LEDGER_JOURNAL_LINES_14203' AS reference_code
UNION ALL
SELECT 14204 AS record_id, 56 AS customer_id, 46 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2819.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 64 AS risk_score, 'LEDGER_JOURNAL_LINES_14204' AS reference_code;
