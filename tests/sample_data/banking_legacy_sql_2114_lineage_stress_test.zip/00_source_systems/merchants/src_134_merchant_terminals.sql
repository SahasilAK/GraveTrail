-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=merchants | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_merchants.merchant_terminals
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_merchants.merchant_terminals AS
SELECT 13401 AS record_id, 45 AS customer_id, 35 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2556.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 35 AS risk_score, 'MERCHANTS_MERCHANT_TERMINALS_13401' AS reference_code
UNION ALL
SELECT 13402 AS record_id, 46 AS customer_id, 36 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2593.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 42 AS risk_score, 'MERCHANTS_MERCHANT_TERMINALS_13402' AS reference_code
UNION ALL
SELECT 13403 AS record_id, 47 AS customer_id, 37 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2630.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 49 AS risk_score, 'MERCHANTS_MERCHANT_TERMINALS_13403' AS reference_code
UNION ALL
SELECT 13404 AS record_id, 48 AS customer_id, 38 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2667.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 56 AS risk_score, 'MERCHANTS_MERCHANT_TERMINALS_13404' AS reference_code;
