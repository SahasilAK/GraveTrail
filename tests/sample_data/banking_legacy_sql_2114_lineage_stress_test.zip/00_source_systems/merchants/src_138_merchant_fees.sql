-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=merchants | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_merchants.merchant_fees
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_merchants.merchant_fees AS
SELECT 13801 AS record_id, 49 AS customer_id, 39 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2632.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 39 AS risk_score, 'MERCHANTS_MERCHANT_FEES_13801' AS reference_code
UNION ALL
SELECT 13802 AS record_id, 50 AS customer_id, 40 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2669.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 46 AS risk_score, 'MERCHANTS_MERCHANT_FEES_13802' AS reference_code
UNION ALL
SELECT 13803 AS record_id, 51 AS customer_id, 41 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2706.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 53 AS risk_score, 'MERCHANTS_MERCHANT_FEES_13803' AS reference_code
UNION ALL
SELECT 13804 AS record_id, 52 AS customer_id, 42 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2743.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 60 AS risk_score, 'MERCHANTS_MERCHANT_FEES_13804' AS reference_code;
