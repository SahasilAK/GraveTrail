-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=merchants | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_merchants.acquiring_transactions
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_merchants.acquiring_transactions AS
SELECT 13501 AS record_id, 46 AS customer_id, 36 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2575.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 36 AS risk_score, 'MERCHANTS_ACQUIRING_TRANSACTIONS_13501' AS reference_code
UNION ALL
SELECT 13502 AS record_id, 47 AS customer_id, 37 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2612.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 43 AS risk_score, 'MERCHANTS_ACQUIRING_TRANSACTIONS_13502' AS reference_code
UNION ALL
SELECT 13503 AS record_id, 48 AS customer_id, 38 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2649.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 50 AS risk_score, 'MERCHANTS_ACQUIRING_TRANSACTIONS_13503' AS reference_code
UNION ALL
SELECT 13504 AS record_id, 49 AS customer_id, 39 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2686.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 57 AS risk_score, 'MERCHANTS_ACQUIRING_TRANSACTIONS_13504' AS reference_code;
