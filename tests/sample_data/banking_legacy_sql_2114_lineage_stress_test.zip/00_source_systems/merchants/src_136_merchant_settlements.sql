-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=merchants | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_merchants.merchant_settlements
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_merchants.merchant_settlements AS
SELECT 13601 AS record_id, 47 AS customer_id, 37 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2594.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 37 AS risk_score, 'MERCHANTS_MERCHANT_SETTLEMENTS_13601' AS reference_code
UNION ALL
SELECT 13602 AS record_id, 48 AS customer_id, 38 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2631.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 44 AS risk_score, 'MERCHANTS_MERCHANT_SETTLEMENTS_13602' AS reference_code
UNION ALL
SELECT 13603 AS record_id, 49 AS customer_id, 39 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2668.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 51 AS risk_score, 'MERCHANTS_MERCHANT_SETTLEMENTS_13603' AS reference_code
UNION ALL
SELECT 13604 AS record_id, 50 AS customer_id, 40 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2705.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 58 AS risk_score, 'MERCHANTS_MERCHANT_SETTLEMENTS_13604' AS reference_code;
