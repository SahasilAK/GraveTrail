-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=fraud | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_fraud.anomalous_logins
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_fraud.anomalous_logins AS
SELECT 8301 AS record_id, 84 AS customer_id, 34 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1587.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 83 AS risk_score, 'FRAUD_ANOMALOUS_LOGINS_8301' AS reference_code
UNION ALL
SELECT 8302 AS record_id, 85 AS customer_id, 35 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1624.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 90 AS risk_score, 'FRAUD_ANOMALOUS_LOGINS_8302' AS reference_code
UNION ALL
SELECT 8303 AS record_id, 86 AS customer_id, 36 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1661.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 97 AS risk_score, 'FRAUD_ANOMALOUS_LOGINS_8303' AS reference_code
UNION ALL
SELECT 8304 AS record_id, 87 AS customer_id, 37 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1698.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 5 AS risk_score, 'FRAUD_ANOMALOUS_LOGINS_8304' AS reference_code;
