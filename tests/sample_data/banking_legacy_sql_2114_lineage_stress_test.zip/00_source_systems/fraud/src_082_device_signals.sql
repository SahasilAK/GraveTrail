-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=fraud | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_fraud.device_signals
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_fraud.device_signals AS
SELECT 8201 AS record_id, 83 AS customer_id, 33 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1568.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 82 AS risk_score, 'FRAUD_DEVICE_SIGNALS_8201' AS reference_code
UNION ALL
SELECT 8202 AS record_id, 84 AS customer_id, 34 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1605.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 89 AS risk_score, 'FRAUD_DEVICE_SIGNALS_8202' AS reference_code
UNION ALL
SELECT 8203 AS record_id, 85 AS customer_id, 35 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1642.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 96 AS risk_score, 'FRAUD_DEVICE_SIGNALS_8203' AS reference_code
UNION ALL
SELECT 8204 AS record_id, 86 AS customer_id, 36 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1679.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 4 AS risk_score, 'FRAUD_DEVICE_SIGNALS_8204' AS reference_code;
