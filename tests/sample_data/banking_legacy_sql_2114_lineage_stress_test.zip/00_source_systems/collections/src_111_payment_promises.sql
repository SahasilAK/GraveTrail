-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=collections | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_collections.payment_promises
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_collections.payment_promises AS
SELECT 11101 AS record_id, 22 AS customer_id, 12 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2119.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 12 AS risk_score, 'COLLECTIONS_PAYMENT_PROMISES_11101' AS reference_code
UNION ALL
SELECT 11102 AS record_id, 23 AS customer_id, 13 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2156.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 19 AS risk_score, 'COLLECTIONS_PAYMENT_PROMISES_11102' AS reference_code
UNION ALL
SELECT 11103 AS record_id, 24 AS customer_id, 14 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2193.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 26 AS risk_score, 'COLLECTIONS_PAYMENT_PROMISES_11103' AS reference_code
UNION ALL
SELECT 11104 AS record_id, 25 AS customer_id, 15 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2230.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 33 AS risk_score, 'COLLECTIONS_PAYMENT_PROMISES_11104' AS reference_code;
