-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=collections | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_collections.delinquency_cases
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_collections.delinquency_cases AS
SELECT 10901 AS record_id, 20 AS customer_id, 10 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2081.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 10 AS risk_score, 'COLLECTIONS_DELINQUENCY_CASES_10901' AS reference_code
UNION ALL
SELECT 10902 AS record_id, 21 AS customer_id, 11 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2118.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 17 AS risk_score, 'COLLECTIONS_DELINQUENCY_CASES_10902' AS reference_code
UNION ALL
SELECT 10903 AS record_id, 22 AS customer_id, 12 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2155.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 24 AS risk_score, 'COLLECTIONS_DELINQUENCY_CASES_10903' AS reference_code
UNION ALL
SELECT 10904 AS record_id, 23 AS customer_id, 13 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2192.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 31 AS risk_score, 'COLLECTIONS_DELINQUENCY_CASES_10904' AS reference_code;
