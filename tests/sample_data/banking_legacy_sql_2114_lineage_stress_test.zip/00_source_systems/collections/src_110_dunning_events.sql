-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=collections | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_collections.dunning_events
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_collections.dunning_events AS
SELECT 11001 AS record_id, 21 AS customer_id, 11 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2100.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 11 AS risk_score, 'COLLECTIONS_DUNNING_EVENTS_11001' AS reference_code
UNION ALL
SELECT 11002 AS record_id, 22 AS customer_id, 12 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2137.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 18 AS risk_score, 'COLLECTIONS_DUNNING_EVENTS_11002' AS reference_code
UNION ALL
SELECT 11003 AS record_id, 23 AS customer_id, 13 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2174.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 25 AS risk_score, 'COLLECTIONS_DUNNING_EVENTS_11003' AS reference_code
UNION ALL
SELECT 11004 AS record_id, 24 AS customer_id, 14 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2211.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 32 AS risk_score, 'COLLECTIONS_DUNNING_EVENTS_11004' AS reference_code;
