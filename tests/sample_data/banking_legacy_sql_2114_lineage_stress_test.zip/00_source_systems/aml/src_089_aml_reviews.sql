-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=aml | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_aml.aml_reviews
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_aml.aml_reviews AS
SELECT 8901 AS record_id, 90 AS customer_id, 40 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1701.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 89 AS risk_score, 'AML_AML_REVIEWS_8901' AS reference_code
UNION ALL
SELECT 8902 AS record_id, 1 AS customer_id, 41 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1738.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 96 AS risk_score, 'AML_AML_REVIEWS_8902' AS reference_code
UNION ALL
SELECT 8903 AS record_id, 2 AS customer_id, 42 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1775.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 4 AS risk_score, 'AML_AML_REVIEWS_8903' AS reference_code
UNION ALL
SELECT 8904 AS record_id, 3 AS customer_id, 43 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1812.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 11 AS risk_score, 'AML_AML_REVIEWS_8904' AS reference_code;
