-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=aml | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_aml.watchlist_matches
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_aml.watchlist_matches AS
SELECT 8601 AS record_id, 87 AS customer_id, 37 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1644.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 86 AS risk_score, 'AML_WATCHLIST_MATCHES_8601' AS reference_code
UNION ALL
SELECT 8602 AS record_id, 88 AS customer_id, 38 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1681.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 93 AS risk_score, 'AML_WATCHLIST_MATCHES_8602' AS reference_code
UNION ALL
SELECT 8603 AS record_id, 89 AS customer_id, 39 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1718.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 1 AS risk_score, 'AML_WATCHLIST_MATCHES_8603' AS reference_code
UNION ALL
SELECT 8604 AS record_id, 90 AS customer_id, 40 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1755.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 8 AS risk_score, 'AML_WATCHLIST_MATCHES_8604' AS reference_code;
