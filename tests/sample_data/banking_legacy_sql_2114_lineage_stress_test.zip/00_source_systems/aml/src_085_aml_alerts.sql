-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=aml | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_aml.aml_alerts
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_aml.aml_alerts AS
SELECT 8501 AS record_id, 86 AS customer_id, 36 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1625.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 85 AS risk_score, 'AML_AML_ALERTS_8501' AS reference_code
UNION ALL
SELECT 8502 AS record_id, 87 AS customer_id, 37 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1662.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 92 AS risk_score, 'AML_AML_ALERTS_8502' AS reference_code
UNION ALL
SELECT 8503 AS record_id, 88 AS customer_id, 38 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1699.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 0 AS risk_score, 'AML_AML_ALERTS_8503' AS reference_code
UNION ALL
SELECT 8504 AS record_id, 89 AS customer_id, 39 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1736.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 7 AS risk_score, 'AML_AML_ALERTS_8504' AS reference_code;
