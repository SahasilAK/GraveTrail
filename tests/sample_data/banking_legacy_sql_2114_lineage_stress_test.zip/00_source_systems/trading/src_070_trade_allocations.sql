-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=trading | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_trading.trade_allocations
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_trading.trade_allocations AS
SELECT 7001 AS record_id, 71 AS customer_id, 21 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1340.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 70 AS risk_score, 'TRADING_TRADE_ALLOCATIONS_7001' AS reference_code
UNION ALL
SELECT 7002 AS record_id, 72 AS customer_id, 22 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1377.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 77 AS risk_score, 'TRADING_TRADE_ALLOCATIONS_7002' AS reference_code
UNION ALL
SELECT 7003 AS record_id, 73 AS customer_id, 23 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1414.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 84 AS risk_score, 'TRADING_TRADE_ALLOCATIONS_7003' AS reference_code
UNION ALL
SELECT 7004 AS record_id, 74 AS customer_id, 24 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1451.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 91 AS risk_score, 'TRADING_TRADE_ALLOCATIONS_7004' AS reference_code;
