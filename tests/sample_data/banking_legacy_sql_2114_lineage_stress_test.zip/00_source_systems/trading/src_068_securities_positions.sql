-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=trading | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_trading.securities_positions
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_trading.securities_positions AS
SELECT 6801 AS record_id, 69 AS customer_id, 19 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1302.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 68 AS risk_score, 'TRADING_SECURITIES_POSITIONS_6801' AS reference_code
UNION ALL
SELECT 6802 AS record_id, 70 AS customer_id, 20 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1339.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 75 AS risk_score, 'TRADING_SECURITIES_POSITIONS_6802' AS reference_code
UNION ALL
SELECT 6803 AS record_id, 71 AS customer_id, 21 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1376.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 82 AS risk_score, 'TRADING_SECURITIES_POSITIONS_6803' AS reference_code
UNION ALL
SELECT 6804 AS record_id, 72 AS customer_id, 22 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1413.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 89 AS risk_score, 'TRADING_SECURITIES_POSITIONS_6804' AS reference_code;
