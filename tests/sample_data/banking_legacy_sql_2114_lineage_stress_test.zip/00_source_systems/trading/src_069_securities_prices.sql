-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=trading | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_trading.securities_prices
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_trading.securities_prices AS
SELECT 6901 AS record_id, 70 AS customer_id, 20 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1321.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 69 AS risk_score, 'TRADING_SECURITIES_PRICES_6901' AS reference_code
UNION ALL
SELECT 6902 AS record_id, 71 AS customer_id, 21 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1358.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 76 AS risk_score, 'TRADING_SECURITIES_PRICES_6902' AS reference_code
UNION ALL
SELECT 6903 AS record_id, 72 AS customer_id, 22 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1395.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 83 AS risk_score, 'TRADING_SECURITIES_PRICES_6903' AS reference_code
UNION ALL
SELECT 6904 AS record_id, 73 AS customer_id, 23 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1432.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 90 AS risk_score, 'TRADING_SECURITIES_PRICES_6904' AS reference_code;
