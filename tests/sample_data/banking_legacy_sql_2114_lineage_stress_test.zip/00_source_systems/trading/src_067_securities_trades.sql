-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=trading | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_trading.securities_trades
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_trading.securities_trades AS
SELECT 6701 AS record_id, 68 AS customer_id, 18 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1283.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 67 AS risk_score, 'TRADING_SECURITIES_TRADES_6701' AS reference_code
UNION ALL
SELECT 6702 AS record_id, 69 AS customer_id, 19 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1320.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 74 AS risk_score, 'TRADING_SECURITIES_TRADES_6702' AS reference_code
UNION ALL
SELECT 6703 AS record_id, 70 AS customer_id, 20 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1357.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 81 AS risk_score, 'TRADING_SECURITIES_TRADES_6703' AS reference_code
UNION ALL
SELECT 6704 AS record_id, 71 AS customer_id, 21 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1394.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 88 AS risk_score, 'TRADING_SECURITIES_TRADES_6704' AS reference_code;
