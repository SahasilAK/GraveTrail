-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=trading | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_trading.corporate_actions
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_trading.corporate_actions AS
SELECT 7201 AS record_id, 73 AS customer_id, 23 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1378.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 72 AS risk_score, 'TRADING_CORPORATE_ACTIONS_7201' AS reference_code
UNION ALL
SELECT 7202 AS record_id, 74 AS customer_id, 24 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1415.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 79 AS risk_score, 'TRADING_CORPORATE_ACTIONS_7202' AS reference_code
UNION ALL
SELECT 7203 AS record_id, 75 AS customer_id, 25 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1452.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 86 AS risk_score, 'TRADING_CORPORATE_ACTIONS_7203' AS reference_code
UNION ALL
SELECT 7204 AS record_id, 76 AS customer_id, 26 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1489.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 93 AS risk_score, 'TRADING_CORPORATE_ACTIONS_7204' AS reference_code;
