-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=transfers | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_transfers.beneficiary_records
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_transfers.beneficiary_records AS
SELECT 4701 AS record_id, 48 AS customer_id, 48 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 903.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 47 AS risk_score, 'TRANSFERS_BENEFICIARY_RECORDS_4701' AS reference_code
UNION ALL
SELECT 4702 AS record_id, 49 AS customer_id, 49 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 940.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 54 AS risk_score, 'TRANSFERS_BENEFICIARY_RECORDS_4702' AS reference_code
UNION ALL
SELECT 4703 AS record_id, 50 AS customer_id, 50 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 977.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 61 AS risk_score, 'TRANSFERS_BENEFICIARY_RECORDS_4703' AS reference_code
UNION ALL
SELECT 4704 AS record_id, 51 AS customer_id, 1 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1014.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 68 AS risk_score, 'TRANSFERS_BENEFICIARY_RECORDS_4704' AS reference_code;
