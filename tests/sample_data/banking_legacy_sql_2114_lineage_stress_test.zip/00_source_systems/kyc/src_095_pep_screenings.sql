-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=kyc | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_kyc.pep_screenings
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_kyc.pep_screenings AS
SELECT 9501 AS record_id, 6 AS customer_id, 46 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1815.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 95 AS risk_score, 'KYC_PEP_SCREENINGS_9501' AS reference_code
UNION ALL
SELECT 9502 AS record_id, 7 AS customer_id, 47 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1852.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 3 AS risk_score, 'KYC_PEP_SCREENINGS_9502' AS reference_code
UNION ALL
SELECT 9503 AS record_id, 8 AS customer_id, 48 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1889.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 10 AS risk_score, 'KYC_PEP_SCREENINGS_9503' AS reference_code
UNION ALL
SELECT 9504 AS record_id, 9 AS customer_id, 49 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1926.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 17 AS risk_score, 'KYC_PEP_SCREENINGS_9504' AS reference_code;
