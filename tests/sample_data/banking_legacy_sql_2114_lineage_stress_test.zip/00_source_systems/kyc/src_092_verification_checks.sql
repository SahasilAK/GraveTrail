-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=kyc | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_kyc.verification_checks
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_kyc.verification_checks AS
SELECT 9201 AS record_id, 3 AS customer_id, 43 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1758.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 92 AS risk_score, 'KYC_VERIFICATION_CHECKS_9201' AS reference_code
UNION ALL
SELECT 9202 AS record_id, 4 AS customer_id, 44 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1795.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 0 AS risk_score, 'KYC_VERIFICATION_CHECKS_9202' AS reference_code
UNION ALL
SELECT 9203 AS record_id, 5 AS customer_id, 45 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1832.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 7 AS risk_score, 'KYC_VERIFICATION_CHECKS_9203' AS reference_code
UNION ALL
SELECT 9204 AS record_id, 6 AS customer_id, 46 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 1869.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 14 AS risk_score, 'KYC_VERIFICATION_CHECKS_9204' AS reference_code;
