-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=mortgages | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_mortgages.mortgage_defaults
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_mortgages.mortgage_defaults AS
SELECT 3001 AS record_id, 31 AS customer_id, 31 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 580.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 30 AS risk_score, 'MORTGAGES_MORTGAGE_DEFAULTS_3001' AS reference_code
UNION ALL
SELECT 3002 AS record_id, 32 AS customer_id, 32 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 617.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 37 AS risk_score, 'MORTGAGES_MORTGAGE_DEFAULTS_3002' AS reference_code
UNION ALL
SELECT 3003 AS record_id, 33 AS customer_id, 33 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 654.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 44 AS risk_score, 'MORTGAGES_MORTGAGE_DEFAULTS_3003' AS reference_code
UNION ALL
SELECT 3004 AS record_id, 34 AS customer_id, 34 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 691.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 51 AS risk_score, 'MORTGAGES_MORTGAGE_DEFAULTS_3004' AS reference_code;
