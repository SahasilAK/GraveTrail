-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=mortgages | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_mortgages.repayment_plans
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_mortgages.repayment_plans AS
SELECT 2901 AS record_id, 30 AS customer_id, 30 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 561.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 29 AS risk_score, 'MORTGAGES_REPAYMENT_PLANS_2901' AS reference_code
UNION ALL
SELECT 2902 AS record_id, 31 AS customer_id, 31 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 598.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 36 AS risk_score, 'MORTGAGES_REPAYMENT_PLANS_2902' AS reference_code
UNION ALL
SELECT 2903 AS record_id, 32 AS customer_id, 32 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 635.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 43 AS risk_score, 'MORTGAGES_REPAYMENT_PLANS_2903' AS reference_code
UNION ALL
SELECT 2904 AS record_id, 33 AS customer_id, 33 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 672.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 50 AS risk_score, 'MORTGAGES_REPAYMENT_PLANS_2904' AS reference_code;
