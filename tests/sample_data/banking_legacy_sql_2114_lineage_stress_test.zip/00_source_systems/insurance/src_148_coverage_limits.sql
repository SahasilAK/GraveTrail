-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=insurance | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_insurance.coverage_limits
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_insurance.coverage_limits AS
SELECT 14801 AS record_id, 59 AS customer_id, 49 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2822.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 49 AS risk_score, 'INSURANCE_COVERAGE_LIMITS_14801' AS reference_code
UNION ALL
SELECT 14802 AS record_id, 60 AS customer_id, 50 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2859.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 56 AS risk_score, 'INSURANCE_COVERAGE_LIMITS_14802' AS reference_code
UNION ALL
SELECT 14803 AS record_id, 61 AS customer_id, 1 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2896.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 63 AS risk_score, 'INSURANCE_COVERAGE_LIMITS_14803' AS reference_code
UNION ALL
SELECT 14804 AS record_id, 62 AS customer_id, 2 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2933.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 70 AS risk_score, 'INSURANCE_COVERAGE_LIMITS_14804' AS reference_code;
