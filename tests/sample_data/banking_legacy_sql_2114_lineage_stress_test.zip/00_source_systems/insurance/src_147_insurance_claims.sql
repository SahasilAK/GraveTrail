-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=insurance | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_insurance.insurance_claims
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_insurance.insurance_claims AS
SELECT 14701 AS record_id, 58 AS customer_id, 48 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2803.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 48 AS risk_score, 'INSURANCE_INSURANCE_CLAIMS_14701' AS reference_code
UNION ALL
SELECT 14702 AS record_id, 59 AS customer_id, 49 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2840.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 55 AS risk_score, 'INSURANCE_INSURANCE_CLAIMS_14702' AS reference_code
UNION ALL
SELECT 14703 AS record_id, 60 AS customer_id, 50 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2877.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 62 AS risk_score, 'INSURANCE_INSURANCE_CLAIMS_14703' AS reference_code
UNION ALL
SELECT 14704 AS record_id, 61 AS customer_id, 1 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2914.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 69 AS risk_score, 'INSURANCE_INSURANCE_CLAIMS_14704' AS reference_code;
