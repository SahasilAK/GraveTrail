-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=insurance | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_insurance.policy_riders
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_insurance.policy_riders AS
SELECT 14901 AS record_id, 60 AS customer_id, 50 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2841.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 50 AS risk_score, 'INSURANCE_POLICY_RIDERS_14901' AS reference_code
UNION ALL
SELECT 14902 AS record_id, 61 AS customer_id, 1 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2878.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 57 AS risk_score, 'INSURANCE_POLICY_RIDERS_14902' AS reference_code
UNION ALL
SELECT 14903 AS record_id, 62 AS customer_id, 2 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2915.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 64 AS risk_score, 'INSURANCE_POLICY_RIDERS_14903' AS reference_code
UNION ALL
SELECT 14904 AS record_id, 63 AS customer_id, 3 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2952.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 71 AS risk_score, 'INSURANCE_POLICY_RIDERS_14904' AS reference_code;
