-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=branches | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_branches.branch_directory
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_branches.branch_directory AS
SELECT 11501 AS record_id, 26 AS customer_id, 16 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2195.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 16 AS risk_score, 'BRANCHES_BRANCH_DIRECTORY_11501' AS reference_code
UNION ALL
SELECT 11502 AS record_id, 27 AS customer_id, 17 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2232.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 23 AS risk_score, 'BRANCHES_BRANCH_DIRECTORY_11502' AS reference_code
UNION ALL
SELECT 11503 AS record_id, 28 AS customer_id, 18 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2269.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 30 AS risk_score, 'BRANCHES_BRANCH_DIRECTORY_11503' AS reference_code
UNION ALL
SELECT 11504 AS record_id, 29 AS customer_id, 19 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2306.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 37 AS risk_score, 'BRANCHES_BRANCH_DIRECTORY_11504' AS reference_code;
