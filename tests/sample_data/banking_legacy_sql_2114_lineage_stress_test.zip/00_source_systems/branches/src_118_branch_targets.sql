-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=branches | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_branches.branch_targets
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_branches.branch_targets AS
SELECT 11801 AS record_id, 29 AS customer_id, 19 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2252.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 19 AS risk_score, 'BRANCHES_BRANCH_TARGETS_11801' AS reference_code
UNION ALL
SELECT 11802 AS record_id, 30 AS customer_id, 20 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2289.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 26 AS risk_score, 'BRANCHES_BRANCH_TARGETS_11802' AS reference_code
UNION ALL
SELECT 11803 AS record_id, 31 AS customer_id, 21 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2326.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 33 AS risk_score, 'BRANCHES_BRANCH_TARGETS_11803' AS reference_code
UNION ALL
SELECT 11804 AS record_id, 32 AS customer_id, 22 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2363.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 40 AS risk_score, 'BRANCHES_BRANCH_TARGETS_11804' AS reference_code;
