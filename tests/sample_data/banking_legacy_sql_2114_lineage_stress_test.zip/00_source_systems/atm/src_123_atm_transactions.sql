-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=atm | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_atm.atm_transactions
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_atm.atm_transactions AS
SELECT 12301 AS record_id, 34 AS customer_id, 24 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2347.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 24 AS risk_score, 'ATM_ATM_TRANSACTIONS_12301' AS reference_code
UNION ALL
SELECT 12302 AS record_id, 35 AS customer_id, 25 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2384.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 31 AS risk_score, 'ATM_ATM_TRANSACTIONS_12302' AS reference_code
UNION ALL
SELECT 12303 AS record_id, 36 AS customer_id, 26 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2421.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 38 AS risk_score, 'ATM_ATM_TRANSACTIONS_12303' AS reference_code
UNION ALL
SELECT 12304 AS record_id, 37 AS customer_id, 27 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2458.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 45 AS risk_score, 'ATM_ATM_TRANSACTIONS_12304' AS reference_code;
