-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=atm | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_atm.atm_devices
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_atm.atm_devices AS
SELECT 12101 AS record_id, 32 AS customer_id, 22 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2309.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 22 AS risk_score, 'ATM_ATM_DEVICES_12101' AS reference_code
UNION ALL
SELECT 12102 AS record_id, 33 AS customer_id, 23 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2346.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 29 AS risk_score, 'ATM_ATM_DEVICES_12102' AS reference_code
UNION ALL
SELECT 12103 AS record_id, 34 AS customer_id, 24 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2383.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 36 AS risk_score, 'ATM_ATM_DEVICES_12103' AS reference_code
UNION ALL
SELECT 12104 AS record_id, 35 AS customer_id, 25 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2420.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 43 AS risk_score, 'ATM_ATM_DEVICES_12104' AS reference_code;
