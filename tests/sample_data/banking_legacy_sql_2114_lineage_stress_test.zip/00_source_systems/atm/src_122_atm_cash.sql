-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=atm | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_atm.atm_cash
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_atm.atm_cash AS
SELECT 12201 AS record_id, 33 AS customer_id, 23 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 2328.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 23 AS risk_score, 'ATM_ATM_CASH_12201' AS reference_code
UNION ALL
SELECT 12202 AS record_id, 34 AS customer_id, 24 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 2365.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 30 AS risk_score, 'ATM_ATM_CASH_12202' AS reference_code
UNION ALL
SELECT 12203 AS record_id, 35 AS customer_id, 25 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2402.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 37 AS risk_score, 'ATM_ATM_CASH_12203' AS reference_code
UNION ALL
SELECT 12204 AS record_id, 36 AS customer_id, 26 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2439.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 44 AS risk_score, 'ATM_ATM_CASH_12204' AS reference_code;
