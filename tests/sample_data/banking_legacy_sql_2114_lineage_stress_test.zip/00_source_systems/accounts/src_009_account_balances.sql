-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=accounts | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_accounts.account_balances
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_accounts.account_balances AS
SELECT 901 AS record_id, 10 AS customer_id, 10 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 181.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 9 AS risk_score, 'ACCOUNTS_ACCOUNT_BALANCES_901' AS reference_code
UNION ALL
SELECT 902 AS record_id, 11 AS customer_id, 11 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 218.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 16 AS risk_score, 'ACCOUNTS_ACCOUNT_BALANCES_902' AS reference_code
UNION ALL
SELECT 903 AS record_id, 12 AS customer_id, 12 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 255.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 23 AS risk_score, 'ACCOUNTS_ACCOUNT_BALANCES_903' AS reference_code
UNION ALL
SELECT 904 AS record_id, 13 AS customer_id, 13 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 292.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 30 AS risk_score, 'ACCOUNTS_ACCOUNT_BALANCES_904' AS reference_code;
