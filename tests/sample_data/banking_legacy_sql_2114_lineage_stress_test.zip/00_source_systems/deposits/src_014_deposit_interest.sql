-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=deposits | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_deposits.deposit_interest
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_deposits.deposit_interest AS
SELECT 1401 AS record_id, 15 AS customer_id, 15 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 276.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 14 AS risk_score, 'DEPOSITS_DEPOSIT_INTEREST_1401' AS reference_code
UNION ALL
SELECT 1402 AS record_id, 16 AS customer_id, 16 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 313.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 21 AS risk_score, 'DEPOSITS_DEPOSIT_INTEREST_1402' AS reference_code
UNION ALL
SELECT 1403 AS record_id, 17 AS customer_id, 17 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 350.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 28 AS risk_score, 'DEPOSITS_DEPOSIT_INTEREST_1403' AS reference_code
UNION ALL
SELECT 1404 AS record_id, 18 AS customer_id, 18 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 387.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 35 AS risk_score, 'DEPOSITS_DEPOSIT_INTEREST_1404' AS reference_code;
