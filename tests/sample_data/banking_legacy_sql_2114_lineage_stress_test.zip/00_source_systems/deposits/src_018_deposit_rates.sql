-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=deposits | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_deposits.deposit_rates
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_deposits.deposit_rates AS
SELECT 1801 AS record_id, 19 AS customer_id, 19 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 352.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 18 AS risk_score, 'DEPOSITS_DEPOSIT_RATES_1801' AS reference_code
UNION ALL
SELECT 1802 AS record_id, 20 AS customer_id, 20 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 389.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 25 AS risk_score, 'DEPOSITS_DEPOSIT_RATES_1802' AS reference_code
UNION ALL
SELECT 1803 AS record_id, 21 AS customer_id, 21 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 426.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 32 AS risk_score, 'DEPOSITS_DEPOSIT_RATES_1803' AS reference_code
UNION ALL
SELECT 1804 AS record_id, 22 AS customer_id, 22 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 463.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 39 AS risk_score, 'DEPOSITS_DEPOSIT_RATES_1804' AS reference_code;
