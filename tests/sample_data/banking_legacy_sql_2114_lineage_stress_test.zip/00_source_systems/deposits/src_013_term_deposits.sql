-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=deposits | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_deposits.term_deposits
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_deposits.term_deposits AS
SELECT 1301 AS record_id, 14 AS customer_id, 14 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 257.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 13 AS risk_score, 'DEPOSITS_TERM_DEPOSITS_1301' AS reference_code
UNION ALL
SELECT 1302 AS record_id, 15 AS customer_id, 15 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 294.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 20 AS risk_score, 'DEPOSITS_TERM_DEPOSITS_1302' AS reference_code
UNION ALL
SELECT 1303 AS record_id, 16 AS customer_id, 16 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 331.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 27 AS risk_score, 'DEPOSITS_TERM_DEPOSITS_1303' AS reference_code
UNION ALL
SELECT 1304 AS record_id, 17 AS customer_id, 17 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 368.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 34 AS risk_score, 'DEPOSITS_TERM_DEPOSITS_1304' AS reference_code;
