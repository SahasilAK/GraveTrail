-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=compliance | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_compliance.regulatory_findings
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_compliance.regulatory_findings AS
SELECT 10001 AS record_id, 11 AS customer_id, 1 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1910.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 1 AS risk_score, 'COMPLIANCE_REGULATORY_FINDINGS_10001' AS reference_code
UNION ALL
SELECT 10002 AS record_id, 12 AS customer_id, 2 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1947.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 8 AS risk_score, 'COMPLIANCE_REGULATORY_FINDINGS_10002' AS reference_code
UNION ALL
SELECT 10003 AS record_id, 13 AS customer_id, 3 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 1984.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 15 AS risk_score, 'COMPLIANCE_REGULATORY_FINDINGS_10003' AS reference_code
UNION ALL
SELECT 10004 AS record_id, 14 AS customer_id, 4 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2021.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 22 AS risk_score, 'COMPLIANCE_REGULATORY_FINDINGS_10004' AS reference_code;
