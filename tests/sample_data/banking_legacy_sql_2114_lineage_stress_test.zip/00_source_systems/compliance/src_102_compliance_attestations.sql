-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=compliance | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_compliance.compliance_attestations
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_compliance.compliance_attestations AS
SELECT 10201 AS record_id, 13 AS customer_id, 3 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 1948.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 3 AS risk_score, 'COMPLIANCE_COMPLIANCE_ATTESTATIONS_10201' AS reference_code
UNION ALL
SELECT 10202 AS record_id, 14 AS customer_id, 4 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 1985.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 10 AS risk_score, 'COMPLIANCE_COMPLIANCE_ATTESTATIONS_10202' AS reference_code
UNION ALL
SELECT 10203 AS record_id, 15 AS customer_id, 5 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 2022.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 17 AS risk_score, 'COMPLIANCE_COMPLIANCE_ATTESTATIONS_10203' AS reference_code
UNION ALL
SELECT 10204 AS record_id, 16 AS customer_id, 6 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 2059.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 24 AS risk_score, 'COMPLIANCE_COMPLIANCE_ATTESTATIONS_10204' AS reference_code;
