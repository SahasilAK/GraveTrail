-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=lending | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_lending.loan_payments
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_lending.loan_payments AS
SELECT 2101 AS record_id, 22 AS customer_id, 22 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 409.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 21 AS risk_score, 'LENDING_LOAN_PAYMENTS_2101' AS reference_code
UNION ALL
SELECT 2102 AS record_id, 23 AS customer_id, 23 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 446.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 28 AS risk_score, 'LENDING_LOAN_PAYMENTS_2102' AS reference_code
UNION ALL
SELECT 2103 AS record_id, 24 AS customer_id, 24 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 483.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 35 AS risk_score, 'LENDING_LOAN_PAYMENTS_2103' AS reference_code
UNION ALL
SELECT 2104 AS record_id, 25 AS customer_id, 25 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 520.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 42 AS risk_score, 'LENDING_LOAN_PAYMENTS_2104' AS reference_code;
