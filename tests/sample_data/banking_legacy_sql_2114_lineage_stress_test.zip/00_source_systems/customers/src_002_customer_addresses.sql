-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=source | domain=customers | dialect=ansi | scenario=static_seed_create_or_replace
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: (none)
-- expected_outputs: legacy_customers.customer_addresses
-- notes: Four synthetic rows with schema suitable for downstream joins

CREATE OR REPLACE TABLE legacy_customers.customer_addresses AS
SELECT 201 AS record_id, 3 AS customer_id, 3 AS account_id, '2024-01-10' AS event_date, '2026-09-10' AS updated_at, 48.25 AS amount, 'ACTIVE' AS status, 'USD' AS currency_code, 1 AS branch_id, 'MAINFRAME' AS source_system, 'BRANCH' AS channel_code, 2 AS risk_score, 'CUSTOMERS_CUSTOMER_ADDRESSES_201' AS reference_code
UNION ALL
SELECT 202 AS record_id, 4 AS customer_id, 4 AS account_id, '2025-02-11' AS event_date, '2026-09-11' AS updated_at, 85.25 AS amount, 'PENDING' AS status, 'EUR' AS currency_code, 2 AS branch_id, 'CORE' AS source_system, 'WEB' AS channel_code, 9 AS risk_score, 'CUSTOMERS_CUSTOMER_ADDRESSES_202' AS reference_code
UNION ALL
SELECT 203 AS record_id, 5 AS customer_id, 5 AS account_id, '2024-03-12' AS event_date, '2026-09-12' AS updated_at, 122.25 AS amount, 'CLOSED' AS status, 'GBP' AS currency_code, 3 AS branch_id, 'SWIFT' AS source_system, 'ATM' AS channel_code, 16 AS risk_score, 'CUSTOMERS_CUSTOMER_ADDRESSES_203' AS reference_code
UNION ALL
SELECT 204 AS record_id, 6 AS customer_id, 6 AS account_id, '2025-04-13' AS event_date, '2026-09-13' AS updated_at, 159.25 AS amount, 'REVIEW' AS status, 'INR' AS currency_code, 4 AS branch_id, 'CARD' AS source_system, 'API' AS channel_code, 23 AS risk_score, 'CUSTOMERS_CUSTOMER_ADDRESSES_204' AS reference_code;
