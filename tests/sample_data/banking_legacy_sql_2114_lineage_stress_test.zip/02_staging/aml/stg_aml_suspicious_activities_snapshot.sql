-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=aml | dialect=ansi | scenario=stage_csv_like_structured_parse
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.aml_suspicious_activities_snapshot, ref.currency_codes
-- expected_outputs: stg.aml_suspicious_activities_snapshot

CREATE OR REPLACE TABLE stg.aml_suspicious_activities_snapshot AS
WITH src AS (SELECT * FROM landing.aml_suspicious_activities_snapshot WHERE amount IS NOT NULL),
flags AS (SELECT src.*, CASE WHEN risk_score >= 70 THEN 'HIGH' WHEN risk_score >= 35 THEN 'MEDIUM' ELSE 'LOW' END AS risk_tier FROM src)
SELECT f.*, c.description AS currency_desc
FROM flags f LEFT JOIN ref.currency_codes c ON c.code=f.currency_code;
