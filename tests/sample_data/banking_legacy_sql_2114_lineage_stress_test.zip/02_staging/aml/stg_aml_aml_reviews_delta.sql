-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=aml | dialect=ansi | scenario=stage_window_rank
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.aml_aml_reviews_delta, ref.currency_codes
-- expected_outputs: stg.aml_aml_reviews_delta

CREATE OR REPLACE TABLE stg.aml_aml_reviews_delta AS
WITH s0 AS (SELECT * FROM landing.aml_aml_reviews_delta), s1 AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY record_id ORDER BY updated_at DESC) AS rn FROM s0)
SELECT s1.record_id, s1.customer_id, s1.account_id, s1.event_date, s1.updated_at, s1.amount, s1.status, s1.currency_code, s1.branch_id, s1.source_system, s1.channel_code, s1.risk_score, s1.reference_code, c.description AS currency_desc
FROM s1 LEFT JOIN ref.currency_codes c ON c.code=s1.currency_code WHERE s1.rn=1;
