-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=accounts | dialect=ansi | scenario=stage_cleanse_case_normalize
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.accounts_account_holds_snapshot, ref.currency_codes
-- expected_outputs: stg.accounts_account_holds_snapshot

CREATE OR REPLACE TABLE stg.accounts_account_holds_snapshot AS
WITH s0 AS (SELECT * FROM landing.accounts_account_holds_snapshot), s1 AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY record_id ORDER BY updated_at DESC) AS rn FROM s0)
SELECT s1.record_id, s1.customer_id, s1.account_id, s1.event_date, s1.updated_at, s1.amount, s1.status, s1.currency_code, s1.branch_id, s1.source_system, s1.channel_code, s1.risk_score, s1.reference_code, c.description AS currency_desc
FROM s1 LEFT JOIN ref.currency_codes c ON c.code=s1.currency_code WHERE s1.rn=1;
