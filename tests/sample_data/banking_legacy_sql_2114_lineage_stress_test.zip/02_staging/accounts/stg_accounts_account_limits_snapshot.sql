-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=accounts | dialect=ansi | scenario=stage_csv_like_structured_parse
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.accounts_account_limits_snapshot, ref.currency_codes
-- expected_outputs: stg.accounts_account_limits_snapshot

CREATE OR REPLACE TABLE stg.accounts_account_limits_snapshot AS
SELECT p.record_id, p.customer_id, p.account_id, p.event_date, p.updated_at,
  ROUND(COALESCE(p.amount,0),2) AS amount, p.status, p.currency_code,
  p.branch_id, p.source_system, p.channel_code, p.risk_score, p.reference_code,
  c.description AS currency_desc
FROM landing.accounts_account_limits_snapshot p
LEFT JOIN ref.currency_codes c ON c.code=p.currency_code;
