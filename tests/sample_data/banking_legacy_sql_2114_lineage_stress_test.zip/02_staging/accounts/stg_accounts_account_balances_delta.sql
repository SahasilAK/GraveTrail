-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=accounts | dialect=ansi | scenario=stage_window_rank
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.accounts_account_balances_delta, ref.currency_codes
-- expected_outputs: stg.accounts_account_balances_delta

CREATE OR REPLACE TABLE stg.accounts_account_balances_delta AS
WITH src AS (SELECT * FROM landing.accounts_account_balances_delta WHERE amount IS NOT NULL),
flags AS (SELECT src.*, CASE WHEN risk_score >= 70 THEN 'HIGH' WHEN risk_score >= 35 THEN 'MEDIUM' ELSE 'LOW' END AS risk_tier FROM src)
SELECT f.*, c.description AS currency_desc
FROM flags f LEFT JOIN ref.currency_codes c ON c.code=f.currency_code;
