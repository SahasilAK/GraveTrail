-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=ach | dialect=ansi | scenario=stage_window_rank
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.ach_ach_batches_delta, ref.currency_codes
-- expected_outputs: stg.ach_ach_batches_delta

CREATE OR REPLACE TABLE stg.ach_ach_batches_delta AS
WITH normalized AS (
 SELECT record_id, customer_id, account_id, event_date, updated_at,
        COALESCE(amount,0) AS amount, UPPER(TRIM(status)) AS status, UPPER(TRIM(currency_code)) AS currency_code,
        branch_id, source_system, channel_code, risk_score, reference_code
 FROM landing.ach_ach_batches_delta
), enriched AS (
 SELECT n.*, COALESCE(c.description,'Unknown Currency') AS currency_desc
 FROM normalized n LEFT JOIN ref.currency_codes c ON c.code = n.currency_code
)
SELECT * FROM enriched WHERE status <> 'DELETED';
