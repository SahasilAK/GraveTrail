-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=ach | dialect=ansi | scenario=stage_csv_like_structured_parse
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.ach_ach_reversals_snapshot, ref.currency_codes
-- expected_outputs: stg.ach_ach_reversals_snapshot

CREATE OR REPLACE TABLE stg.ach_ach_reversals_snapshot AS
SELECT x.*, c.description AS currency_desc FROM (
 SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
 FROM landing.ach_ach_reversals_snapshot
 WHERE COALESCE(amount,0) >= 0
) x LEFT JOIN ref.currency_codes c ON x.currency_code=c.code;
