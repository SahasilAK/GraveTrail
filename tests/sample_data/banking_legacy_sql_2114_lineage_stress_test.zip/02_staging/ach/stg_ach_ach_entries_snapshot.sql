-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=stage | domain=ach | dialect=ansi | scenario=stage_null_standardization
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: landing.ach_ach_entries_snapshot, ref.currency_codes
-- expected_outputs: stg.ach_ach_entries_snapshot

CREATE OR REPLACE TABLE stg.ach_ach_entries_snapshot AS
SELECT t.record_id, t.customer_id, t.account_id, t.event_date, t.updated_at,
       CASE WHEN t.amount < 0 THEN 0 ELSE t.amount END AS amount,
       UPPER(t.status) AS status, t.currency_code, t.branch_id, t.source_system,
       t.channel_code, t.risk_score, t.reference_code, r.description AS currency_desc
FROM landing.ach_ach_entries_snapshot t
LEFT JOIN ref.currency_codes r ON r.code = t.currency_code
WHERE t.customer_id IS NOT NULL;
