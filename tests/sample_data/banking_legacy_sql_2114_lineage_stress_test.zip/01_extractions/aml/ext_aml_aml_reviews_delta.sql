-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=aml | dialect=ansi | scenario=incremental_cdc_predicate
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_aml.aml_reviews
-- expected_outputs: landing.aml_aml_reviews_delta

CREATE OR REPLACE TABLE landing.aml_aml_reviews_delta AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_aml.aml_reviews
WHERE updated_at >= '2026-09-01' AND status <> 'DELETED';
