-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=fx | dialect=ansi | scenario=snapshot_date_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_fx.fx_rates
-- expected_outputs: landing.fx_fx_rates_snapshot

CREATE OR REPLACE TABLE landing.fx_fx_rates_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_fx.fx_rates
WHERE event_date >= '2024-01-01' AND event_date < '2027-01-01';
