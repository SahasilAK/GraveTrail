-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=collateral | dialect=ansi | scenario=incremental_cdc_predicate
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_collateral.lien_records
-- expected_outputs: landing.collateral_lien_records_delta

CREATE OR REPLACE TABLE landing.collateral_lien_records_delta AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_collateral.lien_records
WHERE updated_at >= '2026-09-01' AND status <> 'DELETED';
