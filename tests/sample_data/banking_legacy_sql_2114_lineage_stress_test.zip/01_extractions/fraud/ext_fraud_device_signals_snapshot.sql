-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=fraud | dialect=ansi | scenario=snapshot_predicate_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_fraud.device_signals
-- expected_outputs: landing.fraud_device_signals_snapshot

CREATE OR REPLACE TABLE landing.fraud_device_signals_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_fraud.device_signals
WHERE status IN ('ACTIVE','PENDING','REVIEW') AND amount IS NOT NULL;
