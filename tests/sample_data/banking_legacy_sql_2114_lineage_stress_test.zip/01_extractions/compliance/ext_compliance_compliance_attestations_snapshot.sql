-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=compliance | dialect=ansi | scenario=snapshot_predicate_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_compliance.compliance_attestations
-- expected_outputs: landing.compliance_compliance_attestations_snapshot

CREATE OR REPLACE TABLE landing.compliance_compliance_attestations_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_compliance.compliance_attestations
WHERE status IN ('ACTIVE','PENDING','REVIEW') AND amount IS NOT NULL;
