-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=compliance | dialect=ansi | scenario=snapshot_correlated_exists
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_compliance.policy_exceptions
-- expected_outputs: landing.compliance_policy_exceptions_snapshot

CREATE OR REPLACE TABLE landing.compliance_policy_exceptions_snapshot AS
SELECT s.record_id, s.customer_id, s.account_id, s.event_date, s.updated_at, s.amount, s.status, s.currency_code, s.branch_id, s.source_system, s.channel_code, s.risk_score, s.reference_code
FROM legacy_compliance.policy_exceptions AS s
WHERE EXISTS (SELECT 1 FROM legacy_compliance.policy_exceptions k WHERE k.record_id = s.record_id);
