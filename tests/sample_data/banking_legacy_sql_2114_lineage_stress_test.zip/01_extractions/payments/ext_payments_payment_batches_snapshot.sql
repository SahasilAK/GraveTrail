-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=payments | dialect=ansi | scenario=snapshot_correlated_exists
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_payments.payment_batches
-- expected_outputs: landing.payments_payment_batches_snapshot

CREATE OR REPLACE TABLE landing.payments_payment_batches_snapshot AS
SELECT s.record_id, s.customer_id, s.account_id, s.event_date, s.updated_at, s.amount, s.status, s.currency_code, s.branch_id, s.source_system, s.channel_code, s.risk_score, s.reference_code
FROM legacy_payments.payment_batches AS s
WHERE EXISTS (SELECT 1 FROM legacy_payments.payment_batches k WHERE k.record_id = s.record_id);
