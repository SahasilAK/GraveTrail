-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=payments | dialect=ansi | scenario=snapshot_date_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_payments.payment_returns
-- expected_outputs: landing.payments_payment_returns_snapshot

CREATE OR REPLACE TABLE landing.payments_payment_returns_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_payments.payment_returns
WHERE event_date >= '2024-01-01' AND event_date < '2027-01-01';
