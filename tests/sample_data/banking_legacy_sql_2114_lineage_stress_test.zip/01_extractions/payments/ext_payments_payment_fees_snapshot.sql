-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=payments | dialect=ansi | scenario=snapshot_predicate_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_payments.payment_fees
-- expected_outputs: landing.payments_payment_fees_snapshot

CREATE OR REPLACE TABLE landing.payments_payment_fees_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_payments.payment_fees
WHERE status IN ('ACTIVE','PENDING','REVIEW') AND amount IS NOT NULL;
