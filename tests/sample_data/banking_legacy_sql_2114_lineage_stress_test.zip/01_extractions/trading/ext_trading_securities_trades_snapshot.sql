-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=trading | dialect=ansi | scenario=snapshot_predicate_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_trading.securities_trades
-- expected_outputs: landing.trading_securities_trades_snapshot

CREATE OR REPLACE TABLE landing.trading_securities_trades_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_trading.securities_trades
WHERE status IN ('ACTIVE','PENDING','REVIEW') AND amount IS NOT NULL;
