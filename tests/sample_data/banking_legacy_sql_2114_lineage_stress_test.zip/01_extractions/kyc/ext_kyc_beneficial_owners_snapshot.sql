-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=kyc | dialect=ansi | scenario=snapshot_correlated_exists
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_kyc.beneficial_owners
-- expected_outputs: landing.kyc_beneficial_owners_snapshot

CREATE OR REPLACE TABLE landing.kyc_beneficial_owners_snapshot AS
SELECT s.record_id, s.customer_id, s.account_id, s.event_date, s.updated_at, s.amount, s.status, s.currency_code, s.branch_id, s.source_system, s.channel_code, s.risk_score, s.reference_code
FROM legacy_kyc.beneficial_owners AS s
WHERE EXISTS (SELECT 1 FROM legacy_kyc.beneficial_owners k WHERE k.record_id = s.record_id);
