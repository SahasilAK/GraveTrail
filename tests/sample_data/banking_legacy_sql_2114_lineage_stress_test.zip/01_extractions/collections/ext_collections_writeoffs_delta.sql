-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=collections | dialect=ansi | scenario=incremental_cdc_predicate
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_collections.writeoffs
-- expected_outputs: landing.collections_writeoffs_delta

CREATE OR REPLACE TABLE landing.collections_writeoffs_delta AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_collections.writeoffs
WHERE updated_at >= '2026-09-01' AND status <> 'DELETED';
