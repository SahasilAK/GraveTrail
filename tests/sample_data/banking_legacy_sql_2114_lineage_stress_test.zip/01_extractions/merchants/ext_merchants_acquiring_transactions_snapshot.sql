-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=merchants | dialect=ansi | scenario=snapshot_date_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_merchants.acquiring_transactions
-- expected_outputs: landing.merchants_acquiring_transactions_snapshot

CREATE OR REPLACE TABLE landing.merchants_acquiring_transactions_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_merchants.acquiring_transactions
WHERE event_date >= '2024-01-01' AND event_date < '2027-01-01';
