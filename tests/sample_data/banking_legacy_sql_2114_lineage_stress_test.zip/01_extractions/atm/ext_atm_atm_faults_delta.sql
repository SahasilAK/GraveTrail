-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=atm | dialect=ansi | scenario=incremental_cdc_predicate
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_atm.atm_faults
-- expected_outputs: landing.atm_atm_faults_delta

CREATE OR REPLACE TABLE landing.atm_atm_faults_delta AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_atm.atm_faults
WHERE updated_at >= '2026-09-01' AND status <> 'DELETED';
