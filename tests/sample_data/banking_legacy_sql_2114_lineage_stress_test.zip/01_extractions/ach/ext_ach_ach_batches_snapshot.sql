-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=ach | dialect=ansi | scenario=snapshot_distinct_quality_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_ach.ach_batches
-- expected_outputs: landing.ach_ach_batches_snapshot

CREATE OR REPLACE TABLE landing.ach_ach_batches_snapshot AS
SELECT DISTINCT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_ach.ach_batches
WHERE TRIM(reference_code) <> '' AND amount >= 0;
