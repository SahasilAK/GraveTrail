-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=transfers | dialect=ansi | scenario=snapshot_correlated_exists
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_transfers.transfer_fees
-- expected_outputs: landing.transfers_transfer_fees_snapshot

CREATE OR REPLACE TABLE landing.transfers_transfer_fees_snapshot AS
SELECT s.record_id, s.customer_id, s.account_id, s.event_date, s.updated_at, s.amount, s.status, s.currency_code, s.branch_id, s.source_system, s.channel_code, s.risk_score, s.reference_code
FROM legacy_transfers.transfer_fees AS s
WHERE EXISTS (SELECT 1 FROM legacy_transfers.transfer_fees k WHERE k.record_id = s.record_id);
