-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=transfers | dialect=ansi | scenario=incremental_cdc_window_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_transfers.transfer_fees
-- expected_outputs: landing.transfers_transfer_fees_delta

CREATE OR REPLACE TABLE landing.transfers_transfer_fees_delta AS
WITH changed AS (SELECT * FROM legacy_transfers.transfer_fees WHERE updated_at >= '2026-09-01'),
ranked AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY record_id ORDER BY updated_at DESC) AS seq FROM changed)
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM ranked WHERE seq = 1;
