-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=accounts | dialect=ansi | scenario=snapshot_correlated_exists
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_accounts.savings_accounts
-- expected_outputs: landing.accounts_savings_accounts_snapshot

CREATE OR REPLACE TABLE landing.accounts_savings_accounts_snapshot AS
SELECT s.record_id, s.customer_id, s.account_id, s.event_date, s.updated_at, s.amount, s.status, s.currency_code, s.branch_id, s.source_system, s.channel_code, s.risk_score, s.reference_code
FROM legacy_accounts.savings_accounts AS s
WHERE EXISTS (SELECT 1 FROM legacy_accounts.savings_accounts k WHERE k.record_id = s.record_id);
