-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=deposits | dialect=ansi | scenario=snapshot_predicate_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_deposits.deposit_payouts
-- expected_outputs: landing.deposits_deposit_payouts_snapshot

CREATE OR REPLACE TABLE landing.deposits_deposit_payouts_snapshot AS
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_deposits.deposit_payouts
WHERE status IN ('ACTIVE','PENDING','REVIEW') AND amount IS NOT NULL;
