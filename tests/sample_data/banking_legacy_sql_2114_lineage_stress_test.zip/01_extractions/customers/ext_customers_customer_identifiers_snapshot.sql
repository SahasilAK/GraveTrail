-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=customers | dialect=ansi | scenario=snapshot_distinct_quality_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_customers.customer_identifiers
-- expected_outputs: landing.customers_customer_identifiers_snapshot

CREATE OR REPLACE TABLE landing.customers_customer_identifiers_snapshot AS
SELECT DISTINCT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_customers.customer_identifiers
WHERE TRIM(reference_code) <> '' AND amount >= 0;
