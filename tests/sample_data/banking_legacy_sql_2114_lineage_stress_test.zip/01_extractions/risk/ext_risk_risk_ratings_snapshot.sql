-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=risk | dialect=ansi | scenario=snapshot_distinct_quality_filter
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_risk.risk_ratings
-- expected_outputs: landing.risk_risk_ratings_snapshot

CREATE OR REPLACE TABLE landing.risk_risk_ratings_snapshot AS
SELECT DISTINCT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM legacy_risk.risk_ratings
WHERE TRIM(reference_code) <> '' AND amount >= 0;
