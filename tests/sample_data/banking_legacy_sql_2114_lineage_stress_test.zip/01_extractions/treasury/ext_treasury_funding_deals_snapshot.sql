-- FIXTURE: SYNTHETIC BANKING SQL ESTATE | seed=20261018
-- layer=extract | domain=treasury | dialect=ansi | scenario=snapshot_multi_cte_window_dedup
-- parsing_expected=supported | NOT real customer/financial data
-- expected_inputs: legacy_treasury.funding_deals
-- expected_outputs: landing.treasury_funding_deals_snapshot

CREATE OR REPLACE TABLE landing.treasury_funding_deals_snapshot AS
WITH base AS (
    SELECT t.*, ROW_NUMBER() OVER (PARTITION BY t.record_id ORDER BY t.updated_at DESC) AS row_num
    FROM legacy_treasury.funding_deals t
), latest AS (
    SELECT * FROM base WHERE row_num = 1
)
SELECT record_id, customer_id, account_id, event_date, updated_at, amount, status, currency_code, branch_id, source_system, channel_code, risk_score, reference_code
FROM latest;
